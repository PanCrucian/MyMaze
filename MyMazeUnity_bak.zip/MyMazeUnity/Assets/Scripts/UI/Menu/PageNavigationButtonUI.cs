﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

[RequireComponent(typeof(Button))]
public class PageNavigationButtonUI : MonoBehaviour {

}
