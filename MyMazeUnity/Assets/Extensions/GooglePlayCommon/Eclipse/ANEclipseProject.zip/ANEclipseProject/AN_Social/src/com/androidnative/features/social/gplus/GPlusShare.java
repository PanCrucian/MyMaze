package com.androidnative.features.social.gplus;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;

import com.androidnative.features.social.common.SocialGate;
import com.androidnative.features.social.common.SocialProxyActivity;
import com.androidnative.features.social.utils.Base64;
import com.androidnative.features.social.utils.SocialConf;
import com.google.android.gms.plus.PlusShare;
import com.unity3d.player.UnityPlayer;

public class GPlusShare {
	
	public static String DEEP_LINK_MANAGER = "AN_DeepLinkingManager";
	public static String DEEP_LINK_LISTENER_CALLBACK = "DeepLinkReceived";
	public static String PLUS_SHARE_LISTENER = "AN_PlusShareListener";
	public static String PLUS_SHARE_LISTENER_CALLBACK = "OnPlusShareCallback";
	
	private static final String ANDROID_NATIVE_PREFS = "ANDROID_NATIVE_PREFS";
	private static final String LAUNCHED_DEEPLINK_ID = "LAUNCHED_DEEPLINK_ID";
	
	private static GPlusShare _instance;
	
	public static GPlusShare GetInstance() {
		if(_instance == null) {
			_instance =  new GPlusShare();
		}
		
		return _instance;
	}
	
	public void GetLaunchDeepLinkId() {
		SharedPreferences prefs = SocialConf.GetLauncherActivity().getSharedPreferences(ANDROID_NATIVE_PREFS, Context.MODE_PRIVATE);
		String id = prefs.getString(LAUNCHED_DEEPLINK_ID, "");
		
		Log.d("AndroidNative", "GetLaunchDeepLinkId deepLinkId:" + id);
		//UnityPlayer.UnitySendMessage(DEEP_LINK_MANAGER, DEEP_LINK_LISTENER_CALLBACK, ParseDeepLinkActivity._launcherDeepLinkId);
		
		Log.d("AndroidNative", "Deep link ID returned " + ParseDeepLinkActivity._launcherDeepLinkId);
		if (!id.equals("")) {
			SharedPreferences.Editor editor = prefs.edit();
        	editor.remove(LAUNCHED_DEEPLINK_ID);
        	editor.commit();
		}
	}
	
	public void StartGooglePlusShare(String message, String[] images) {
		
		Log.d("AndroidNative", "StartGooglePlusShare Message:" + message);
		
		byte[] byteArray;
		try {			
			//String mime = "text/plain";
			PlusShare.Builder share = new PlusShare.Builder(SocialConf.GetLauncherActivity());
		    share.setText(message);
		    		    
			/*for (String media : images) {				
				if (media != "") {
			    	byteArray = Base64.decode(media);
					Uri image =  SocialGate.getImageUri(SocialConf.GetLauncherActivity(), byteArray);
					
					//ContentResolver cr = SocialConf.GetLauncherActivity().getContentResolver();
					//mime = cr.getType(image);
					
				    share.addStream(image);
			    }
			}*/
			
		    //share.setType(mime);
		    share.setContentUrl(Uri.parse("https://play.google.com/store/apps/details?id=fr.pixelprose.dice"));
			share.setContentDeepLinkId("testID", "Title", "Description", null);
		    
			SocialProxyActivity.StartGPlusProxyActivity(share.getIntent());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
