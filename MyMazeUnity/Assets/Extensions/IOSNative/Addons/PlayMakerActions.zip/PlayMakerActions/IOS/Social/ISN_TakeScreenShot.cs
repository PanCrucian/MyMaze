 using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_TakeScreenShot : FsmStateAction {

		public FsmTexture screenshot;
		

		public override void OnEnter() {
			ISN_ScreenShot task  = new GameObject("ISN_ScreenShot").AddComponent<ISN_ScreenShot>();
			task.OnScreenShotComplete += OnComplete;
		}



		private void OnComplete(Texture2D tex) {
			screenshot.Value = tex;
		}





	}
}


