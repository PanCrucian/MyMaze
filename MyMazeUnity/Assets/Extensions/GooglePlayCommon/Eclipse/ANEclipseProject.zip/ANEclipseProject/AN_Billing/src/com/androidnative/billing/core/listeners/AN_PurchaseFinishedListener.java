package com.androidnative.billing.core.listeners;

import android.content.Intent;
import android.util.Log;

import com.androidnative.billing.core.AN_BillingProxyActivity;
import com.androidnative.billing.core.BillingManager;
import com.androidnative.billing.interfaces.OnBillingPurchaseFinishedListener;
import com.androidnative.billing.models.BillingResult;
import com.androidnative.billing.models.Purchase;
import com.unity3d.player.UnityPlayer;

public class AN_PurchaseFinishedListener implements OnBillingPurchaseFinishedListener{

	@Override
	public void onPurchaseFinished(BillingResult result, Purchase purchase) {
		
		Log.d("AndroidNative", "**AN_PurchaseFinishedListener :: Purchase finished**: " + result.getMessage());
		Log.d("AndroidNative", "**AN_PurchaseFinishedListener :: result.isSuccess(): " + result.isSuccess());
		
		StringBuilder callback =  new StringBuilder();
		callback.append(Integer.toString(result.getResponse()));
		callback.append(BillingManager.UNITY_SPLITTER);
		callback.append(result.getMessage());
		

		if (result.isSuccess()) {
			
			
			Log.d("AndroidNative", "**AN_PurchaseFinishedListener :: purchase.getSku(): " + purchase.getSku());
			
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getSku());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getPackageName());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getDeveloperPayload());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getOrderId());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getPurchaseState());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getToken());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getSignature());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getPurchaseTime());
			callback.append(BillingManager.UNITY_SPLITTER);
			callback.append(purchase.getOriginalJson());
			
			if(BillingManager.GetInstance().GetInventory() != null) {
				BillingManager.GetInstance().GetInventory().addPurchase(purchase);
				Log.d("AndroidNative", "**AN_PurchaseFinishedListener added to inventory");
			} 
	    }
		
		
		UnityPlayer.currentActivity.sendBroadcast(new Intent(AN_BillingProxyActivity.ACTION_FINISH));
		UnityPlayer.UnitySendMessage(BillingManager.UNITY_LISTNER_NAME, "OnPurchaseFinishedCallback", callback.toString());
		
	}

}
