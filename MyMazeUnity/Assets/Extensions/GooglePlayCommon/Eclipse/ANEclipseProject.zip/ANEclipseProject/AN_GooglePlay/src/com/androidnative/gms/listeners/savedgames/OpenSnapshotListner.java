package com.androidnative.gms.listeners.savedgames;

import java.io.IOException;

import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.utils.Base64;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.games.snapshot.Snapshots.OpenSnapshotResult;
import com.unity3d.player.UnityPlayer;


public class OpenSnapshotListner implements ResultCallback<OpenSnapshotResult> {
	
	private String _OpenEventName;
	
	public OpenSnapshotListner(String OpenEventName) {
		_OpenEventName = OpenEventName;
	}

	@Override
	public void onResult(OpenSnapshotResult result) {
		 int status = result.getStatus().getStatusCode();
		 
		 StringBuilder  builder = new StringBuilder();
		 builder.append(status);
		 
		 
		 if(status == GamesStatusCodes.STATUS_OK) {
			 
			 try {
				 Snapshot  snapshot = result.getSnapshot();
				 
				 builder.append(GameClientManager.UNITY_SPLITTER);
				 builder.append(snapshot.getMetadata().getTitle());
				 builder.append(GameClientManager.UNITY_SPLITTER);
				 builder.append(snapshot.getMetadata().getLastModifiedTimestamp());
				 builder.append(GameClientManager.UNITY_SPLITTER);
				 builder.append(snapshot.getMetadata().getDescription());
				 builder.append(GameClientManager.UNITY_SPLITTER);
				 builder.append(snapshot.getMetadata().getCoverImageUrl());
				 builder.append(GameClientManager.UNITY_SPLITTER);
				 builder.append(snapshot.getMetadata().getPlayedTime());
				 
				 builder.append(GameClientManager.UNITY_SPLITTER);
				 String data = Base64.encode(snapshot.getSnapshotContents().readFully());
				 builder.append(data);
				 
				 
		         UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, _OpenEventName, builder.toString()); 
			 } catch (IOException e) {
				 Log.d("AndroidNative", "GCM: OpenSnapshotListner onResult Exception:");
		         e.printStackTrace();
			 }
	
		 } 
		 
		 
		 if (status == GamesStatusCodes.STATUS_SNAPSHOT_CONFLICT) {
			 GameClientManager.GetInstance().snedConflict(result);
		 }
		
	}

}
