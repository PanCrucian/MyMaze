package com.androidnative.gms.utils;

public class AN_IdFactory {

	private static int id = 0;
	public static int GetNextId() {
		id++;
		return id;
	}
}
