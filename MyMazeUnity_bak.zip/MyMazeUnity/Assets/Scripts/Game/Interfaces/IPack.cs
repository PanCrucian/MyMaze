﻿public interface IPack {

}
