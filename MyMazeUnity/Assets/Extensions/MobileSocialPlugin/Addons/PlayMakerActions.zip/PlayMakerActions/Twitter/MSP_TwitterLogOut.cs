using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterLogOut : FsmStateAction {

		public override void OnEnter() {
			SPTwitter.instance.LogOut();
			Finish();
		}

	}
}


