﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_GameSavesEventsListener : FsmStateAction {

		public FsmInt MaxNumberOfSavedGamesToShow;
		public FsmString NativeUITitle;

		public FsmEvent GameSaveLoaded;
		public FsmEvent NewGameSaveRequest;

		public FsmString Title;
		public FsmString Description;
		public FsmString CoverImageUri;
		public FsmInt LastModifiedTimestamp;
		public FsmInt TotalPlayedTime;

		public override void OnEnter() {
			GooglePlaySavedGamesManager.ActionGameSaveLoaded += ActionGameSaveLoaded;
			GooglePlaySavedGamesManager.ActionNewGameSaveRequest += ActionNewGameSaveRequest;
			GooglePlaySavedGamesManager.instance.ShowSavedGamesUI(NativeUITitle.Value, MaxNumberOfSavedGamesToShow.Value);
		}

		private void ActionGameSaveLoaded (GP_SpanshotLoadResult result) {
			GooglePlaySavedGamesManager.ActionGameSaveLoaded -= ActionGameSaveLoaded;
			GooglePlaySavedGamesManager.ActionNewGameSaveRequest -= ActionNewGameSaveRequest;

			if(result.isSuccess) {	
				GP_SnapshotMeta snapshot = result.Snapshot.meta;
				
				Title.Value = snapshot.Title;
				Description.Value = snapshot.Description;
				CoverImageUri.Value = snapshot.CoverImageUrl;
				LastModifiedTimestamp.Value = (int)snapshot.LastModifiedTimestamp;
				TotalPlayedTime.Value = (int)snapshot.TotalPlayedTime;

				Fsm.Event(GameSaveLoaded);
				Finish ();
			}
		}

		private void ActionNewGameSaveRequest () {
			GooglePlaySavedGamesManager.ActionGameSaveLoaded -= ActionGameSaveLoaded;
			GooglePlaySavedGamesManager.ActionNewGameSaveRequest -= ActionNewGameSaveRequest;

			Fsm.Event (NewGameSaveRequest);
			Finish ();
		}

	}
}
