﻿using UnityEngine;
using System.Collections;

public class INotDestroyable : MonoBehaviour {
    public bool isLoaded = false;
}
