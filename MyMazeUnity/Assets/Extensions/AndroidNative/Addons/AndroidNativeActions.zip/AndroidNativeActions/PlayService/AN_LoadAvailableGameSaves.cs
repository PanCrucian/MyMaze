﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_LoadAvailableGameSaves : FsmStateAction {

		public FsmEvent Success;
		public FsmEvent Failure;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if (IsInEdditorMode) {
				Fsm.Event(Success);
				Finish();
			}
			
			GooglePlaySavedGamesManager.ActionAvailableGameSavesLoaded += ActionAvailableGameSavesLoaded;
			GooglePlaySavedGamesManager.instance.LoadAvailableSavedGames();
		}
		
		private void ActionAvailableGameSavesLoaded (GooglePlayResult res) {			
			GooglePlaySavedGamesManager.ActionAvailableGameSavesLoaded -= ActionAvailableGameSavesLoaded;
			if(res.isSuccess) {
				Fsm.Event(Success);
				Finish ();
			} else {
				Fsm.Event(Failure);
				Finish();
			}
		}
	}
}
