﻿using UnityEngine;

public class MoveEffectorArrow : MonoBehaviour {
    	
}
