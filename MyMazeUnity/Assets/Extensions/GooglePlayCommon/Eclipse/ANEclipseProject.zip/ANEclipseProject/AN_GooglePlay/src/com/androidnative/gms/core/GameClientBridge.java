package com.androidnative.gms.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import android.content.res.Resources;
import android.util.Log;

import com.androidnative.gms.listeners.savedgames.DeleteSnapShotListner;
import com.androidnative.gms.listeners.savedgames.LoadSnapshotsResultListner;
import com.androidnative.gms.listeners.savedgames.OpenSnapshotListner;
import com.androidnative.gms.network.RealTimeMultiplayerController;
import com.androidnative.gms.network.TurnBasedMultiplayerController;
import com.androidnative.gms.utils.AnUtility;
import com.androidnative.gms.utils.Base64;
import com.androidnative.gms.utils.Base64DecoderException;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.multiplayer.ParticipantResult;
import com.google.android.gms.tagmanager.Container;
import com.google.android.gms.tagmanager.ContainerHolder;
import com.google.android.gms.tagmanager.DataLayer;
import com.google.android.gms.tagmanager.TagManager;


public class GameClientBridge {
	
	// --------------------------------------
	// Google Play Services
	// --------------------------------------
	
	public static void initTagManager(String containerId, String binDataId) {
		TagManager tagManager = TagManager.getInstance(AnUtility.GetApplicationContex());
		tagManager.setVerboseLoggingEnabled(true);
		
		Resources res = AnUtility.GetApplicationContex().getResources();
		int id = res.getIdentifier(binDataId, "raw", AnUtility.GetApplicationContex().getPackageName());
		
		Log.d("AndroidNative", "Google Tag Manager Container ID: " + id);
		
		PendingResult<ContainerHolder> pending = tagManager.loadContainerPreferNonDefault(containerId, id);
		
		// The onResult method will be called as soon as one of the following happens:
		//	     1. a saved container is loaded
		//	     2. if there is no saved container, a network container is loaded
		//	     3. the request times out. The example below uses a constant to manage the timeout period.
		pending.setResultCallback(new ResultCallback<ContainerHolder>() {
		    @Override
		    public void onResult(ContainerHolder containerHolder) {
		        ContainerHolderSingleton.setContainerHolder(containerHolder);
		        Container container = containerHolder.getContainer();
		        if (!containerHolder.getStatus().isSuccess()) {
		            Log.e("AndroidNative", "failure loading container");
		            return;
		        }
		        ContainerHolderSingleton.setContainerHolder(containerHolder);
		        ContainerLoadedCallback.registerCallbacksForContainer(container);
		        containerHolder.setContainerAvailableListener(new ContainerLoadedCallback());
		        
		        Log.d("AndroidNative", "Google Tag Manager Container loaded successfully");
		    }
		}, 2, TimeUnit.SECONDS);
	}
	
	public static void getValueFromContainer(String key) {
		String variable = ContainerHolderSingleton.getContainerHolder().getContainer().getString(key);
		
		Log.d("AndroidNative", "Google Tag Manager Container variable " + variable);
		
		DataLayer dataLayer = TagManager.getInstance(AnUtility.GetApplicationContex()).getDataLayer();
		dataLayer.push("ConstantVariable", "12345");
	}
	
	public static void refreshContainer() {
		ContainerHolderSingleton.getContainerHolder().refresh();
		
		Log.d("AndroidNative", "Google Tag Manager Container refreshed");
	}
	
	public static void pushValue(String key, String value) {
		Log.d("AndroidNative", "Push Value into Tag Manager key " + key + " value " + value);
		
		DataLayer dataLayer = TagManager.getInstance(AnUtility.GetApplicationContex()).getDataLayer();
		dataLayer.push(key, value);
	}
	
	public static void pushEvent(String event, String key, String value) {
		Log.d("AndroidNative", "Push Event into Tag Manager event " + event + " key " + key + " value " + value);
		
		DataLayer dataLayer = TagManager.getInstance(AnUtility.GetApplicationContex()).getDataLayer();
		dataLayer.pushEvent(event, DataLayer.mapOf(key, value));
	}

	public static void playServiceInit(String scopes) {
		try {
			GameClientManager.GetInstance().InitPlayService(scopes);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceInit: "
					+ ex.getMessage());
		}
	}
	
	public static void OnApplicationPause(boolean IsPaused) {
		if(IsPaused) {
			GameClientManager.GetInstance().onStop();
		} else {
			GameClientManager.GetInstance().onStart();
		}
	}
	
	public static void setConnectionParams(String params) {
		try {
			GameClientManager.showConnectingPopup = Boolean.parseBoolean(params);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceConnect: "
					+ ex.getMessage());
		}
	}

	public static void playServiceConnect() {
		try {
			GameClientManager.GetInstance().sighIn();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceConnect: "
					+ ex.getMessage());
		}

	}

	public static void playServiceConnect(String accountName) {
		try {
			GameClientManager.GetInstance().sighIn(accountName);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceConnect: "
					+ ex.getMessage());
		}

	}

	public static void getToken(String accountName, String scope) {
		try {
			GameClientManager.GetInstance().getToken(accountName, scope);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError getToken: " + ex.getMessage());
		}

	}

	public static void invalidateToken(String token) {
		try {
			GameClientManager.GetInstance().invalidateToken(token);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError invalidateToken: "
					+ ex.getMessage());
		}

	}

	public static void loadGoogleAccountNames() {
		try {
			GameClientManager.GetInstance().loadGoogleAccountNames();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadGoogleAccountNames: "
							+ ex.getMessage());
		}

	}

	public static void clearDefaultAccount() {
		try {
			GameClientManager.GetInstance().clearDefaultAccount();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError clearDefaultAccount: "
					+ ex.getMessage());
		}

	}

	public static void revokeAccessAndDisconnect() {
		try {
			GameClientManager.GetInstance().revokeAccessAndDisconnect();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError revokeAccessAndDisconnect: "
							+ ex.getMessage());
		}

	}

	public static void playServiceDisconnect() {
		try {
			GameClientManager.GetInstance().disconnect();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError playServiceDisconnect: "
							+ ex.getMessage());
		}

	}

	public static void showAchievementsUI() {
		try {
			GameClientManager.GetInstance().showAchivmentsUI();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError showAchivments: " + ex.getMessage());
		}

	}

	public static void showLeaderBoards() {
		try {
			GameClientManager.GetInstance().showLeaderBoardsUI();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showLeaderBoards: "
					+ ex.getMessage());
		}

	}

	public static void showLeaderBoard(String leaderboardName) {
		try {
			String leaderboardId = getStringResourceByName(leaderboardName);
			showLeaderBoardById(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError showLeaderBoard" + ex.getMessage());
		}

	}

	public static void showLeaderBoardById(String leaderboardId) {
		try {
			GameClientManager.GetInstance().showLeaderBoardUI(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showLeaderBoardById: "
					+ ex.getMessage());
		}

	}

	public static void loadConnectedPlayers() {
		try {
			GameClientManager.GetInstance().loadConnectedPlayers();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadConnectedPlayers: "
							+ ex.getMessage());
		}

	}

	public static void submitScore(String leaderboardName, String score) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		submitScoreById(leaderboardId, score);
	}

	public static void submitScoreById(String leaderboardId, String score) {
		try {
			GameClientManager.GetInstance().submitScore(leaderboardId,
					Long.parseLong(score));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError submitScoreById: "
					+ ex.getMessage());
		}

	}

	public static void loadLeaderBoards() {
		try {
			GameClientManager.GetInstance().loadLeaderBoards();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadLeaderBoards: "
					+ ex.getMessage());
		}

	}
	
	public static void loadLeaderBoardsLocal(String leaderboardId, int requestId) {
		try {
			GameClientManager.GetInstance().loadLeaderBoardsLocal(leaderboardId, requestId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadLeaderBoards: "
					+ ex.getMessage());
		}
	}

	public static void loadPlayerCenteredScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		try {
			GameClientManager.GetInstance().loadPlayerCenteredScores(
					leaderboardId, Integer.parseInt(span),
					Integer.parseInt(leaderboardCollection),
					Integer.parseInt(maxResults));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadPlayerCenteredScores: "
							+ ex.getMessage());
		}

	}

	public static void loadTopScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		try {
			GameClientManager.GetInstance().loadTopScores(leaderboardId,
					Integer.parseInt(span),
					Integer.parseInt(leaderboardCollection),
					Integer.parseInt(maxResults));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadTopScores: " + ex.getMessage());
		}

	}

	public static void reportAchievement(String achievementName) {

		String achievementId = getStringResourceByName(achievementName);
		reportAchievementById(achievementId);
	}

	public static void reportAchievementById(String achievementId) {
		try {
			GameClientManager.GetInstance().reportAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError reportAchievementById: "
							+ ex.getMessage());
		}

	}

	public static void revealAchievement(String achievementName) {
		Log.d("AndroidNative", "achievementName: " + achievementName);
		String achievementId = getStringResourceByName(achievementName);

		Log.d("AndroidNative", "achievementId: " + achievementId);
		revealAchievementById(achievementId);
	}

	public static void revealAchievementById(String achievementId) {
		try {
			GameClientManager.GetInstance().revealAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError 	GameClientManager.GetInstance().revealAchievement(achievementId);: "
							+ ex.getMessage());
		}

	}

	public static void incrementAchievement(String achievementName, String numsteps) {
		String achievementId = getStringResourceByName(achievementName);
		incrementAchievementById(achievementId, numsteps);
	}

	public static void incrementAchievementById(String achievementId, String numsteps) {
		try {
			GameClientManager.GetInstance().incrementAchievement(achievementId,
					Integer.parseInt(numsteps));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError incrementAchievementById: "
							+ ex.getMessage());
		}

	}
	
	public static void setStepsImmediate(String achievementId, String numsteps) {
		try {
			GameClientManager.GetInstance().setStepsImmediate(achievementId,
					Integer.parseInt(numsteps));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError setStepsImmediate: "
							+ ex.getMessage());
		}

	}

	public static void loadAchievements() {
		try {
			GameClientManager.GetInstance().loadAchievements();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadAchievements: "
					+ ex.getMessage());
		}

	}

	public static void resetAchievement(String achievementId) {
		try {
			GameClientManager.GetInstance().resetAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError resetAchievement: "
					+ ex.getMessage());
		}

	}

	public static void resetAllAchievements() {
		try {
			GameClientManager.GetInstance().resetAllAchievements();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError resetAllAchievements: "
							+ ex.getMessage());
		}

	}

	public static void resetLeaderBoard(String leaderboardId) {
		try {
			GameClientManager.GetInstance().resetLeaderBoard(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError GameClientManager.GetInstance().resetLeaderBoard(leaderboardId);: "
							+ ex.getMessage());
		}

	}

	// --------------------------------------
	// Gifts
	// --------------------------------------

	public static void sendGiftRequest(String type, String playload,
			String requestLifetimeDays, String icon, String description) {
		try {
			GameClientManager.GetInstance().sendGiftRequest(type, playload,
					requestLifetimeDays, icon, description);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sendGiftRequest: "
					+ ex.getMessage());
		}

	}

	public static void showRequestAccepDialog() {
		try {
			GameClientManager.GetInstance().showRequestAccepDialog();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError GameClientManager.GetInstance().showRequestAccepDialog();: "
							+ ex.getMessage());
		}

	}

	public static void acceptRequests(String ids) {
		try {
			GameClientManager.GetInstance().acceptRequests(ids);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError acceptRequests: " + ex.getMessage());
		}

	}

	public static void dismissRequest(String ids) {
		try {
			GameClientManager.GetInstance().dismissRequest(ids);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError dismissRequest: " + ex.getMessage());
		}

	}

	public static void loadPlayerInfo(String playerId) {
		try {
			GameClientManager.GetInstance().loadPlayerInfo(playerId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadPlayerInfo: " + ex.getMessage());
		}

	}

	// --------------------------------------
	// QUESTS AND EVENTS
	// --------------------------------------

	public static void sumbitEvent(String eventId, String count) {
		try {
			GameClientManager.GetInstance().sumbitEvent(eventId,
					Integer.valueOf(count));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError sumbitEvent: " + ex.getMessage());
		}

	}

	public static void loadEvents() {
		try {
			GameClientManager.GetInstance().loadEvents();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadEvents: " + ex.getMessage());
		}

	}

	public static void showSelectedQuests(String questSelectors) {
		try {
			GameClientManager.GetInstance().showSelectedQuests(questSelectors);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showSelectedQuests: "
					+ ex.getMessage());
		}

	}

	public static void acceptQuest(String questId) {
		try {
			GameClientManager.GetInstance().acceptQuest(questId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError acceptQuest: " + ex.getMessage());
		}

	}

	public static void loadQuests(String questSelectors, String sortOrder) {
		try {
			GameClientManager.GetInstance().loadQuests(questSelectors,
					Integer.valueOf(sortOrder));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadQuests: " + ex.getMessage());
		}

	}

	// --------------------------------------
	// RTM
	// --------------------------------------

	public static void RTMFindMatch(int minPlayers, int maxPlayers, String[] playersToInvite) {
		try {
			RealTimeMultiplayerController.GetInstance().findMatch(minPlayers, maxPlayers, playersToInvite);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError RTMFindMatch: " + ex.getMessage());
		}

	}
	
	public static void RTMFindMatch(String[] playersToInvite) {
		try {
			RealTimeMultiplayerController.GetInstance().findMatch(playersToInvite);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError RTMFindMatch: " + ex.getMessage());
		}

	}

	public static void sendDataToAll(String data, String sendType, int dataId) {
		try {
			RealTimeMultiplayerController.GetInstance().sendDataToAll(data,
					Integer.valueOf(sendType), dataId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError sendDataToAll: " + ex.getMessage());
		}

	}

	public static void sendDataToPlayers(String data, String players, String sendType, int dataId) {
		try {
			RealTimeMultiplayerController.GetInstance().sendDataToPlayers(data,
					players, Integer.valueOf(sendType), dataId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sendDataToPlayers: "
					+ ex.getMessage());
		}

	}

	public static void showWaitingRoomIntent() {
		try {
			RealTimeMultiplayerController.GetInstance().showWaitingRoomIntent();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError showWaitingRoomIntent: "
							+ ex.getMessage());
		}

	}

	public static void leaveRoom() {
		try {
			RealTimeMultiplayerController.GetInstance().leaveRoom();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError leaveRoom: " + ex.getMessage());
		}

	}
	
	public static void RTM_AcceptInvitation(String invitationId)  {
		RealTimeMultiplayerController.GetInstance().acceptInviteToRoom(invitationId);
	}
	
	public static void RTM_DeclineInvitation(String invitationId)  {
		RealTimeMultiplayerController.GetInstance().DeclineInvitation(invitationId);
	}
	
	public static void RTM_DismissInvitation(String invitationId)  {
		RealTimeMultiplayerController.GetInstance().DeclineInvitation(invitationId);
	}
	
	

	public static void acceptInviteToRoom(String invId) {
		try {
			
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError acceptInviteToRoom: "
					+ ex.getMessage());
		}

	}

	public static void showInvitationBox() {
		try {
			RealTimeMultiplayerController.GetInstance().showInvitationBox();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showInvitationBox: "
					+ ex.getMessage());
		}

	}

	public static void invitePlayers(String minPlayers, String maxPlayers) {
		try {
			RealTimeMultiplayerController.GetInstance().invitePlayers(
					Integer.valueOf(minPlayers), Integer.valueOf(maxPlayers));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError invitePlayers: " + ex.getMessage());
		}

	}
	

	public static void RTM_SetVariant(int val) {
		RealTimeMultiplayerController.GetInstance().SetVariant(val);
	}
	
	
	//will work only if startSelectOpponentsView minPlayers > 0
	public static void RTM_SetExclusiveBitMask(int val) {
		RealTimeMultiplayerController.GetInstance().SetExclusiveBitMask(val);
	}
	
	

	
	// --------------------------------------
	// Saved Games Bridge
	// --------------------------------------
	
	
	
	public static void CreateNewSpanshot_Bridge(String name, String description, String ImageData, String Data, long PlayedTime) {
		GameClientManager.GetInstance().createNewSpanshot(name, description, ImageData, Data, PlayedTime);
	}
	
	public static void ShowSavedGamesUI_Bridge(String title, int maxNumberOfSavedGamesToShow, boolean allowAddButton, boolean allowDelete) {
		GameClientManager.GetInstance().showSavedGamesUI(title, maxNumberOfSavedGamesToShow, allowAddButton, allowDelete);
	}
	
	public static void ResolveSnapshotsConflict_Bridge(int index) {
		GameClientManager.GetInstance().resolveSnapshotsConflict(index);
	}
	
	public static void OpenSpanshotByName_Bridge(String name) {
		Games.Snapshots.open(GameClientManager.API(), name, true).setResultCallback(new OpenSnapshotListner("OnSavedGamePicked"));
	}
	
	public static void DeleteSpanshotByName_Bridge(String name) {
		Games.Snapshots.open(GameClientManager.API(), name, true).setResultCallback(new DeleteSnapShotListner());
	}
	
	public static void LoadSpanshots_Bridge() {
		Games.Snapshots.load(GameClientManager.API(), true).setResultCallback(new LoadSnapshotsResultListner());
	}
	
	// --------------------------------------
	// Google Cloud  Bridge
	// --------------------------------------
	
	
	public static void ListStates_Bridge() {
		GameClientManager.GetInstance().listStates();
	}

	public static void UpdateState_Bridge(String stateKey, String data) {
		GameClientManager.GetInstance().updateState(Integer.parseInt(stateKey), data);
	}

	public static void DeleteState_Bridge(String stateKey) {
		GameClientManager.GetInstance().deleteState(Integer.parseInt(stateKey));
	}

	public static void LoadState_Bridge(String stateKey) {
		GameClientManager.GetInstance().loadState(Integer.parseInt(stateKey));
	}

	public static void ResolveState_Bridge(String stateKey, String resolvedData,String resolvedVersion) {
		GameClientManager.GetInstance().resolveState(Integer.parseInt(stateKey),
					resolvedData, resolvedVersion);
		
	}
	
	// --------------------------------------
	// Turn-Based Multiplayer
	// --------------------------------------
	
	public static void TBM_AcceptInvitation(String invitationId)  {
		TurnBasedMultiplayerController.GetInstance().AcceptInvitation(invitationId);
	}
	
	public static void TBM_DeclineInvitation(String invitationId)  {
		TurnBasedMultiplayerController.GetInstance().DeclineInvitation(invitationId);
	}
	
	public static void TBM_DismissInvitation(String invitationId)  {
		TurnBasedMultiplayerController.GetInstance().DeclineInvitation(invitationId);
	}
	
	public static void TBM_CreateMatch(int minPlayers, int maxPlayers, String[] playersIds) {
		TurnBasedMultiplayerController.GetInstance().CreateMatch(minPlayers, maxPlayers, playersIds);
	}
	
	public static void CancelMatch(String matchId) {
		TurnBasedMultiplayerController.GetInstance().CancelMatch(matchId);
	}
	
	public static void DismissMatch(String matchId) {
		TurnBasedMultiplayerController.GetInstance().DismissMatch(matchId);
	}	
	
	public static void TBM_FinishMatch(String matchId, String matchData, String[] pIds, int[] results, int[] placing, int[] versions) {
		//ParticipantResult r=  new ParticipantResult("1", 1, 1);
		try {
			ArrayList<ParticipantResult> ParticipantResults =  new ArrayList<ParticipantResult>();
			
			int index = 0;
			for(String id : pIds) {
				ParticipantResult r =  new ParticipantResult(versions[index], id, results[index], placing[index]);
				ParticipantResults.add(r);
				index++;
			}
		
			TurnBasedMultiplayerController.GetInstance().FinishMatch(matchId, Base64.decode(matchData), ParticipantResults);
		} catch (Base64DecoderException e) {
			Log.d("AndroidNative", "TBM_FinishMatch failed: " + e.getMessage());
			e.printStackTrace();
		}
	}	
	
	public static void TBM_LeaveMatch(String matchId) {
		TurnBasedMultiplayerController.GetInstance().LeaveMatch(matchId);
	}
	
	public static void TBM_LeaveMatchDuringTurn(String matchId, String pendingParticipantId) {
		TurnBasedMultiplayerController.GetInstance().LeaveMatchDuringTurn(matchId, pendingParticipantId);
	}
	
	public static void TBM_LoadMatchInfo(String matchId) {
		TurnBasedMultiplayerController.GetInstance().LoadMatch(matchId);
	}
	
	public static void TBM_LoadMatchesInfo(int invitationSortOrder, int[] matchTurnStatuses) {
		TurnBasedMultiplayerController.GetInstance().LoadMatchesInfo(invitationSortOrder, matchTurnStatuses);
	}
	
	public static void TBM_LoadAllMatchesInfo(int invitationSortOrder) {
		TurnBasedMultiplayerController.GetInstance().LoadAllMatchesInfo(invitationSortOrder);
	}
	
	public static void TBM_Rematch(String matchId) {
		TurnBasedMultiplayerController.GetInstance().Rematch(matchId);
	}
	
	public static void TBM_RegisterMatchUpdateListener() {
		TurnBasedMultiplayerController.GetInstance().RegisterMatchUpdateListener();
	}
	
	public static void TBM_UnregisterMatchUpdateListener() {
		TurnBasedMultiplayerController.GetInstance().UnregisterMatchUpdateListener();
	}
	
	public static void TBM_TakeTrun(String matchId, String matchData, String pendingParticipantId, String[] pIds, int[] results, int[] placing, int[] versions) {
		//ParticipantResult r=  new ParticipantResult("1", 1, 1);
		try {
			ArrayList<ParticipantResult> ParticipantResults =  new ArrayList<ParticipantResult>();
			
			int index = 0;
			for(String id : pIds) {
				ParticipantResult r =  new ParticipantResult(versions[index], id, results[index], placing[index]);
				ParticipantResults.add(r);
				index++;
			}
		
			TurnBasedMultiplayerController.GetInstance().TakeTrun(matchId, Base64.decode(matchData), pendingParticipantId, ParticipantResults);
		} catch (Base64DecoderException e) {
			Log.d("AndroidNative", "TBM_FinishMatch failed: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public static void StartSelectOpponentsView(int minPlayers, int maxPlayers, boolean allowAutomatch) {
		TurnBasedMultiplayerController.GetInstance().StartSelectOpponentsView(minPlayers, maxPlayers, allowAutomatch);
	}
	public static void TBM_ShowInbox() {
		TurnBasedMultiplayerController.GetInstance().ShowInbox();
	}	
	
	public static void TBM_SetVariant(int val) {
		TurnBasedMultiplayerController.GetInstance().SetVariant(val);
	}
	
	
	//will work only if startSelectOpponentsView minPlayers > 0
	public static void TBM_SetExclusiveBitMask(int val) {
		TurnBasedMultiplayerController.GetInstance().SetExclusiveBitMask(val);
	}		

	// --------------------------------------
	// Private Methods
	// --------------------------------------

	private static String getStringResourceByName(String aString) {
		String packageName = AnUtility.GetLauncherActivity().getPackageName();
		int resId = AnUtility.GetLauncherActivity().getResources()
				.getIdentifier(aString, "string", packageName);
		return AnUtility.GetLauncherActivity().getString(resId);
	}
}
