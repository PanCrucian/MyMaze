﻿public class PyramidRecordData
{
    public bool IsUsed;
}
