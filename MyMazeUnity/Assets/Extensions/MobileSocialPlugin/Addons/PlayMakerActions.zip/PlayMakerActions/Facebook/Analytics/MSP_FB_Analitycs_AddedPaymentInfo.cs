﻿using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_AddedPaymentInfo : FsmStateAction {

		public FsmBool IsPaymentInfoAvaliable;

		public override void OnEnter() {
			//The user has entered their payment info.
			SPFacebookAnalytics.AddedPaymentInfo (IsPaymentInfoAvaliable.Value);
			Finish ();
		}
		
	}
}