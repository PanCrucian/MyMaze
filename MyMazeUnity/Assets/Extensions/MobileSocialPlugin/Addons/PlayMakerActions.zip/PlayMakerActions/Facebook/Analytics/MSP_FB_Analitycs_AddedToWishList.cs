﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_AddedToWishList : FsmStateAction {
		
		public FsmFloat price;
		public FsmString id;
		public FsmString type;
		public FsmString currency;
		
		public override void OnEnter() {
			SPFacebookAnalytics.AddedToWishlist(price.Value, id.Value, type.Value, currency.Value);
			Finish ();
		}

		public override void Reset() {
			base.Reset();

			currency =  "USD";		
		}		
	}
}
