Used TexturePacker 3.6.0 for sprites packing
Used plugin for Unity 5 with name TexturePackerImporter