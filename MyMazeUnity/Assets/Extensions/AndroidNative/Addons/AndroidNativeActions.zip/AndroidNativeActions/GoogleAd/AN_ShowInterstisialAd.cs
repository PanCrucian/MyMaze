﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Google Ad")]
	public class AN_ShowInterstisialAd : FsmStateAction {

		[Tooltip("Event fired when Ad is started to show")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when interstitial Ad closed")]
		public FsmEvent failEvent;
		
		public override void OnEnter() {
			AndroidAdMobController.instance.OnInterstitialOpened += InterstitialOpened;
			AndroidAdMobController.instance.OnInterstitialClosed += InterstitialClosed;

			AndroidAdMobController.instance.ShowInterstitialAd();
		}

		private void InterstitialOpened() {
			AndroidAdMobController.instance.OnInterstitialOpened -= InterstitialOpened;
			AndroidAdMobController.instance.OnInterstitialClosed += InterstitialClosed;

			Fsm.Event (successEvent);
			Finish();
		}

		private void InterstitialClosed() {
			AndroidAdMobController.instance.OnInterstitialOpened -= InterstitialOpened;
			AndroidAdMobController.instance.OnInterstitialClosed -= InterstitialClosed;

			Fsm.Event (failEvent);
			Finish();
		}

	}
}
