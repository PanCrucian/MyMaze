package com.androidnative.gms.network;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.core.GooglePlaySupportActivity;
import com.androidnative.gms.listeners.tbm.AN_OnCancelMatchResult;
import com.androidnative.gms.listeners.tbm.AN_OnLeaveMatchResult;
import com.androidnative.gms.listeners.tbm.AN_OnLoadMatchResult;
import com.androidnative.gms.listeners.tbm.AN_OnLoadMatchesResult;
import com.androidnative.gms.listeners.tbm.AN_OnMatchInitiatedCallback;
import com.androidnative.gms.listeners.tbm.AN_OnTurnBasedMatchUpdateReceivedListener;
import com.androidnative.gms.listeners.tbm.AN_OnUpdateMatchResult;
import com.androidnative.gms.utils.Base64;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.multiplayer.Multiplayer;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.ParticipantResult;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatch;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatchConfig;
import com.unity3d.player.UnityPlayer;

public class TurnBasedMultiplayerController {

	private static int MatchVeriant = TurnBasedMatch.MATCH_VARIANT_DEFAULT;
	private static int ExclusiveBitMask = 0;

	private static TurnBasedMultiplayerController _instance = null;

	public static TurnBasedMultiplayerController GetInstance() {
		if (_instance == null) {
			_instance = new TurnBasedMultiplayerController();
		}

		return _instance;
	}

	public void AcceptInvitation(String invitationId) {
		Log.d("AndroidNative", "AcceptInvitation " + invitationId);
		Games.TurnBasedMultiplayer.acceptInvitation(GameClientManager.API(),
				invitationId).setResultCallback(
				new AN_OnMatchInitiatedCallback());
	}

	public void DeclineInvitation(String invitationId) {
		Log.d("AndroidNative", "DeclineInvitation " + invitationId);
		Games.TurnBasedMultiplayer.declineInvitation(GameClientManager.API(),
				invitationId);
	}
	
	public void CreateMatch(int minPlayers, int maxPlayers, String[] playersIds) {
		Log.d("AndroidNative", "Create Turn-Based Match: min players " + minPlayers + " maxPlayers " + maxPlayers);
		if (playersIds != null) {
			for (String id : playersIds) {
				Log.d("AndroidNative", "Invited Player ID: " + id);
			}
		}
		Bundle autoMatchCriteria = RoomConfig.createAutoMatchCriteria(minPlayers, maxPlayers, ExclusiveBitMask);
		TurnBasedMatchConfig.Builder tbmMatchBuilder = TurnBasedMatchConfig.builder();
		if (minPlayers != 0 && maxPlayers != 0) {
			tbmMatchBuilder.setAutoMatchCriteria(autoMatchCriteria);
		}
		
		tbmMatchBuilder.setVariant(MatchVeriant);
		if (playersIds != null) {
			tbmMatchBuilder.addInvitedPlayers(new ArrayList<String>(Arrays.asList(playersIds)));
		}
		
		TurnBasedMatchConfig tbmc = tbmMatchBuilder.build();
		Games.TurnBasedMultiplayer.createMatch(GameClientManager.API(), tbmc)
				.setResultCallback(new AN_OnMatchInitiatedCallback());
	}

	public void DismissInvitation(String invitationId) {
		Log.d("AndroidNative", "DismissInvitation " + invitationId);
		Games.TurnBasedMultiplayer.dismissInvitation(GameClientManager.API(),
				invitationId);
	}

	public void CancelMatch(String matchId) {
		Log.d("AndroidNative", "CancelMatch " + matchId);
		Games.TurnBasedMultiplayer
				.cancelMatch(GameClientManager.API(), matchId)
				.setResultCallback(new AN_OnCancelMatchResult());
	}

	public void DismissMatch(String matchId) {
		Log.d("AndroidNative", "DismissMatch " + matchId);
		Games.TurnBasedMultiplayer.dismissMatch(GameClientManager.API(),
				matchId);
	}

	public void FinishMatch(String matchId, byte[] matchData,
			List<ParticipantResult> results) {
		Log.d("AndroidNative", "FinishMatch hard code" + matchId);
		
		for (ParticipantResult r : results) {
			Log.d("AndroidNative", "getParticipantId " + r.getParticipantId() + " " + "getResult " + r.getResult() + " " + "getPlacing " + r.getPlacing());
		}
				
		Games.TurnBasedMultiplayer.finishMatch(GameClientManager.API(),
				matchId, matchData, results).setResultCallback(
				new AN_OnUpdateMatchResult());
	}

	public void LeaveMatch(String matchId) {
		Log.d("AndroidNative", "LeaveMatch " + matchId);
		Games.TurnBasedMultiplayer.leaveMatch(GameClientManager.API(), matchId)
				.setResultCallback(new AN_OnLeaveMatchResult());
	}

	public void LeaveMatchDuringTurn(String matchId, String pendingParticipantId) {
		Log.d("AndroidNative", "LeaveMatchDuringTurn " + matchId);
		Games.TurnBasedMultiplayer.leaveMatchDuringTurn(
				GameClientManager.API(), matchId, pendingParticipantId)
				.setResultCallback(new AN_OnLeaveMatchResult());
	}

	public void LoadMatch(String matchId) {
		Log.d("AndroidNative", "LoadMatch " + matchId);
		Games.TurnBasedMultiplayer.loadMatch(GameClientManager.API(), matchId)
				.setResultCallback(new AN_OnLoadMatchResult());
	}

	public void LoadMatchesInfo(int invitationSortOrder, int[] matchTurnStatuses) {
		Log.d("AndroidNative", "LoadMatchesInfo matchTurnStatuses count: "
				+ matchTurnStatuses.length);
		Games.TurnBasedMultiplayer.loadMatchesByStatus(GameClientManager.API(),
				invitationSortOrder, matchTurnStatuses).setResultCallback(
				new AN_OnLoadMatchesResult());
	}

	public void LoadAllMatchesInfo(int invitationSortOrder) {
		Log.d("AndroidNative", "LoadAllMatchesInfo ");
		Games.TurnBasedMultiplayer.loadMatchesByStatus(GameClientManager.API(),
				invitationSortOrder, TurnBasedMatch.MATCH_TURN_STATUS_ALL)
				.setResultCallback(new AN_OnLoadMatchesResult());
	}

	public void Rematch(String matchId) {
		Log.d("AndroidNative", "Rematch " + matchId);
		Games.TurnBasedMultiplayer.rematch(GameClientManager.API(), matchId)
				.setResultCallback(new AN_OnMatchInitiatedCallback());
	}

	public void RegisterMatchUpdateListener() {
		Log.d("AndroidNative", "RegisterMatchUpdateListener!!! ");
		Games.TurnBasedMultiplayer.registerMatchUpdateListener(
				GameClientManager.API(),
				new AN_OnTurnBasedMatchUpdateReceivedListener());
	}

	public void UnregisterMatchUpdateListener() {
		Log.d("AndroidNative", "UnregisterMatchUpdateListener!!! ");
		Games.TurnBasedMultiplayer
				.unregisterMatchUpdateListener(GameClientManager.API());
	}

	public void TakeTrun(String matchId, byte[] matchData,
			String pendingParticipantId, List<ParticipantResult> results) {
		Log.d("AndroidNative", "TakeTrun " + matchId);
		Games.TurnBasedMultiplayer.takeTurn(GameClientManager.API(), matchId,
				matchData, pendingParticipantId, results).setResultCallback(
				new AN_OnUpdateMatchResult());
	}

	public void StartSelectOpponentsView(int minPlayers, int maxPlayers,
			boolean allowAutomatch) {
		Intent intent = Games.TurnBasedMultiplayer
				.getSelectOpponentsIntent(GameClientManager.API(), minPlayers,
						maxPlayers, allowAutomatch);
		GooglePlaySupportActivity.startProxyForResult(intent,
				GameClientManager.TB_SELECT_PLAYERS);
	}

	public void ShowInbox() {
		Intent intent = Games.TurnBasedMultiplayer
				.getInboxIntent(GameClientManager.API());
		GooglePlaySupportActivity.startProxyForResult(intent,
				GameClientManager.TBM_INBOX_RESULT);
		
	}

	public void SetVariant(int val) {
		MatchVeriant = val;
	}

	// will work only if startSelectOpponentsView minPlayers > 0
	public void SetExclusiveBitMask(int val) {
		ExclusiveBitMask = val;
	}

	public void onActivityResult(int request, int response, Intent data) {
		switch (request) {
		case GameClientManager.TB_SELECT_PLAYERS:
			ParceTrunBasedResult(response, data);
			break;
		}
	}

	

	private void ParceTrunBasedResult(int response, Intent data) {
		if (response != Activity.RESULT_OK) {
			// user canceled
			StringBuilder info = new StringBuilder();
			info.append( GameClientManager.TB_SELECT_PLAYERS);
			info.append(GameClientManager.UNITY_SPLITTER);
			info.append(response);
			
			UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_TBM_LISTENER, "OnMatchCreationCanceled", info.toString());
			return;
		}

		// Get the invitee list.
		final ArrayList<String> invitees = data
				.getStringArrayListExtra(Games.EXTRA_PLAYER_IDS);

		// Get auto-match criteria.
		Bundle autoMatchCriteria = null;
		int minAutoMatchPlayers = data.getIntExtra(
				Multiplayer.EXTRA_MIN_AUTOMATCH_PLAYERS, 0);
		int maxAutoMatchPlayers = data.getIntExtra(
				Multiplayer.EXTRA_MAX_AUTOMATCH_PLAYERS, 0);

		if (minAutoMatchPlayers > 0) {
			autoMatchCriteria = RoomConfig.createAutoMatchCriteria(
					minAutoMatchPlayers, maxAutoMatchPlayers, ExclusiveBitMask);
		} else {
			autoMatchCriteria = null;
		}

		TurnBasedMatchConfig tbmc = TurnBasedMatchConfig.builder()
				.addInvitedPlayers(invitees)
				.setAutoMatchCriteria(autoMatchCriteria)
				.setVariant(MatchVeriant).build();

		// Create and start the match.
		Games.TurnBasedMultiplayer.createMatch(GameClientManager.API(), tbmc)
				.setResultCallback(new AN_OnMatchInitiatedCallback());
	}

	public static String GetMatchString(TurnBasedMatch m) {

		StringBuilder builder = new StringBuilder();
		builder.append(m.getMatchId());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getRematchId());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getDescription());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getAvailableAutoMatchSlots());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getCreationTimestamp());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getCreatorId());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getLastUpdatedTimestamp());
		builder.append(GameClientManager.UNITY_SPLITTER);
		
		builder.append(m.getLastUpdaterId());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getMatchNumber());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getStatus());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getTurnStatus());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.canRematch());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getVariant());
		builder.append(GameClientManager.UNITY_SPLITTER);

		builder.append(m.getVersion());
		builder.append(GameClientManager.UNITY_SPLITTER);

		byte[] data = m.getData();
		String Data = "";
		if (data != null) {
			Data = Base64.encode(data);
		}
		builder.append(Data);
		builder.append(GameClientManager.UNITY_SPLITTER);

		data = m.getPreviousMatchData();
		String PreviousMatchData = "";
		if (data != null) {
			PreviousMatchData = Base64.encode(data);
		}
		builder.append(PreviousMatchData);
		builder.append(GameClientManager.UNITY_SPLITTER);
		
		builder.append(m.getPendingParticipantId());
		
		ArrayList<Participant> participants = m.getParticipants();
		//Save all match Participants, if they exist
		if (participants.size() > 0) {
			builder.append(GameClientManager.UNITY_SPLITTER);
			builder.append(GameClientManager.SerializeParticipantsInfo(participants));
		}

		return builder.toString();
	}

}
