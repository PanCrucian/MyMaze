﻿using UnityEngine;
using System.Collections;

public enum GateStates {
    Opened,
    Closed
}
