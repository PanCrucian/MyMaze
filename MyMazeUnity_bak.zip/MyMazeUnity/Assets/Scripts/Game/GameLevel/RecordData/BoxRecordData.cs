﻿public class BoxRecordData
{
    public bool colliderEnabled;
}
