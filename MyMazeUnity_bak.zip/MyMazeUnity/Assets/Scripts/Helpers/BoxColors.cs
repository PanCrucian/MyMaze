﻿using UnityEngine;
using System.Collections;

public enum BoxColors {
    White,
    Yellow
}
