﻿public enum PlayerControlTypes {
    RigidbodyImpulse,
    RigidbodyMove
}
