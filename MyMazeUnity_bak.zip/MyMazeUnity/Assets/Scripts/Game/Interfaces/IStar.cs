﻿public interface IStar {
   
    void Collect();

    void Lose();
}
