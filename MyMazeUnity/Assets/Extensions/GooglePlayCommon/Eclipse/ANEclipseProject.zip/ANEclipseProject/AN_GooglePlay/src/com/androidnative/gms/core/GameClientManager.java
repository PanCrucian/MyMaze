package com.androidnative.gms.core;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

//import com.androidnative.gms.listeners.appstate.StateDeleteListener;
//import com.androidnative.gms.listeners.appstate.StateUpdateListener;
//import com.androidnative.gms.listeners.appstate.StatesLoadedListener;
import com.androidnative.gms.listeners.games.AchievementsLoadListner;
import com.androidnative.gms.listeners.games.AchievementsUpdateListner;
import com.androidnative.gms.listeners.games.LeaderBoardScoreLoaded;
import com.androidnative.gms.listeners.games.LeaderBoardsLoadedListener;
import com.androidnative.gms.listeners.games.PlayerResultListner;
import com.androidnative.gms.listeners.games.PlayerScoreUpdateListner;
import com.androidnative.gms.listeners.games.ScoreSubmitedListner;
import com.androidnative.gms.listeners.quests.AN_AcceptQuestResultListner;
import com.androidnative.gms.listeners.quests.AN_ClaimMilestoneResult;
import com.androidnative.gms.listeners.quests.AN_EventsLoadListner;
import com.androidnative.gms.listeners.quests.AN_LoadQuestsResult;
import com.androidnative.gms.listeners.quests.AN_QuestUpdateListener;
import com.androidnative.gms.listeners.requests.AN_UpdateRequestsResultListner;
import com.androidnative.gms.listeners.savedgames.OpenSnapshotListner;
import com.androidnative.gms.listeners.savedgames.SnapshotCreateListner;
import com.androidnative.gms.network.RealTimeMultiplayerController;
import com.androidnative.gms.network.TurnBasedMultiplayerController;
import com.androidnative.gms.utils.AnUtility;
import com.androidnative.gms.utils.Base64;
import com.androidnative.gms.utils.Base64DecoderException;
import com.androidnative.gms.utils.PS_Utility;

//import com.google.android.gms.appstate.AppStateManager;
//import com.google.android.gms.appstate.AppStateStatusCodes;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.GamesActivityResultCodes;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.leaderboard.LeaderboardVariant;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.games.quest.QuestUpdateListener;
import com.google.android.gms.games.quest.Quests;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.games.snapshot.SnapshotContents;
import com.google.android.gms.games.snapshot.SnapshotMetadata;
import com.google.android.gms.games.snapshot.Snapshots;
import com.google.android.gms.plus.Plus;
import com.unity3d.player.UnityPlayer;

@SuppressWarnings("deprecation")
@SuppressLint("NewApi")
public class GameClientManager implements GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks , QuestUpdateListener {

	protected NewGameHelper mHelper;

	public static final int ACHIEVEMENTS_REQUEST = 20001;
	public static final int LEADER_BOARDS_REQUEST = 20002;
	public static final int GIFT_REQUEST = 20003;
	public static final int REQUESTS_INBOX_DIALOG = 20004;	
	
	public static final int RC_SELECT_PLAYERS = 10000;
	public static final int RTM_INBOX_RESULT = 10001;
	public static final int RC_WAITING_ROOM = 10002;
	
	public static final int RC_LIST_SAVED_GAME = 30001;
	
	//Trun Based 
	public static final int TB_SELECT_PLAYERS = 40000;
	public static final int TBM_INBOX_RESULT = 40001;
	
	
	

	private static final String CONNECTION_LISTNER_NAME = "GooglePlayConnection";
	public static final String PlAY_SERVICE_LISTNER_NAME = "GooglePlayManager";
	public static final String GOOGLE_PlAY_EVENTS_LISTNER_NAME = "GooglePlayEvents";
	public static final String GOOGLE_PlAY_QUESTS_LISTNER_NAME = "GooglePlayQuests";
	public static final String GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME = "GooglePlaySavedGamesManager";
	
	
	
	public static final String GOOGLE_CLOUD_LISTNER_NAME = "GoogleCloudManager";
	public static final String GOOGLE_PLAY_INIVITATION_LISTENER = "GooglePlayInvitationManager";
	public static final String GOOGLE_PLAY_RTM_LISTENER = "GooglePlayRTM";
	public static final String GOOGLE_PLAY_TBM_LISTENER = "GooglePlayTBM";
	
	
	private static boolean ReconectOnStart = false;
	private static boolean isStarted = false;
	
	public static boolean showConnectingPopup = true;
	
	public static ArrayList<String> loadedPlayers = new ArrayList<String>();
	
	public static final String UNITY_SPLITTER = "|";
	public static final String UNITY_SPLITTER2 = "|%|";
	public static final String UNITY_EOF = "endofline";
	public static final String TAG = "AndroidNative";
	
	/*
     * If we have incoming requests when we connected to the games client, they
     * are here. Otherwise, it's null.
     */
    ArrayList<GameRequest> mRequests;
    public static HashMap<String, GameRequest> gameRequestMap = new HashMap<String, GameRequest>();
    private static GameClientManager _instance = null;
    

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------
    
    public static GameClientManager GetInstance() {
		if (_instance == null) {
			_instance = new GameClientManager();
		}

		return _instance;
		
	}
    
	
	public void InitPlayService(String scopes) {
		printLog("Creating New GC");
		
		if (!isStarted()) {
			isStarted = true;
			mHelper = new NewGameHelper(this, scopes);
			RealTimeMultiplayerController.GetInstance().SetGameHelper(mHelper);
		}
	}
	
	public void sighIn() {
		if(isStarted) {
			if(mHelper != null) {
				
				if(!IsPlayServiceAlavliable()) {
					onSignInFailed();
					return;
				}
				mHelper.sighIn();
			}
		}
	}
	
	public void sighIn(String accountName) {
		if(isStarted) {
			if(mHelper != null) {
				if(!IsPlayServiceAlavliable()) {
					onSignInFailed();
					return;
				}
				
				mHelper.sighIn(accountName);
			}
		}
	}



	// --------------------------------------
	// GET / SET
	// --------------------------------------
	
	public static  boolean  IsAPIConnected() {
		if(GetInstance().mHelper == null) {
			return false;
		} else {
			return GetInstance().mHelper.IsConnected();
		}
	}
	
	public static GoogleApiClient API() {
		return GetInstance().mHelper.getGoogleApiClient();
	}
	
	

	// --------------------------------------
	// SHOULD BE REFERED FROM ACTIVITY
	// --------------------------------------

	public void onStop() {		
		if (!RealTimeMultiplayerController.GetInstance().isRealTimeActive()) {
			ReconectOnStart = mHelper.IsConnected();
			RealTimeMultiplayerController.GetInstance().OnStop();
			disconnect();
		}		
	}
	
	public void onStart() {
		if(ReconectOnStart) {
			Log.d("AndroidNative", "Reconnection on start");
			connect();
		} else {
			Log.d("AndroidNative", "Skipping Reconnection on start");
		}
	}

	
	// --------------------------------------
	// Saved Games 
	// --------------------------------------
	
	
	// --------------------------------------
	// title	The title to display in the action bar of the returned Activity.
	// allowAddButton	Whether or not to display a "create new snapshot" option in the selection UI.
	// allowDelete	Whether or not to provide a delete overflow menu option for each snapshot in the selection UI.
	// maxNumberOfSavedGamesToShow	The maximum number of snapshots to display in the UI. Use DISPLAY_LIMIT_NONE to display all snapshots.
	// --------------------------------------	
	public void showSavedGamesUI(String title, int maxNumberOfSavedGamesToShow, boolean allowAddButton, boolean allowDelete) {
	    Intent savedGamesIntent = Games.Snapshots.getSelectSnapshotIntent(mHelper.getGoogleApiClient(), "See My Saves", allowAddButton, allowDelete, maxNumberOfSavedGamesToShow);
	 
	    GooglePlaySupportActivity.startProxyForResult(savedGamesIntent, RC_LIST_SAVED_GAME);
	}
	
	public void createNewSpanshot(String name, String description, String ImageData, String Data, long PlayedTime) {
		Games.Snapshots.open(mHelper.getGoogleApiClient(), name, true).setResultCallback(new SnapshotCreateListner(name, description, ImageData, Data, PlayedTime));
	}
	
	
	public void resolveSnapshotsConflict(int index) {
		Snapshot resolution;
		if(index == 0) {
			resolution = s1;
		} else {
			resolution = s2;
		}
		
		Games.Snapshots.resolveConflict(mHelper.getGoogleApiClient(), ConflictId, resolution).setResultCallback(new OpenSnapshotListner("OnSavedGamePicked"));
		
	}
	
	private Snapshot s1;
	private Snapshot s2;
	private String ConflictId;
	
	public void snedConflict(Snapshots.OpenSnapshotResult Sresult) {
		s1 = Sresult.getSnapshot();
		s2 = Sresult.getConflictingSnapshot();
        ConflictId =  Sresult.getConflictId();
       
        try {
        	StringBuilder  result = new StringBuilder();
            
    		result.append(s1.getMetadata().getTitle());
    		result.append(UNITY_SPLITTER);
    		result.append(s1.getMetadata().getLastModifiedTimestamp());
    		result.append(UNITY_SPLITTER);
    		result.append(s1.getMetadata().getDescription());
    		result.append(UNITY_SPLITTER);
    		result.append(s1.getMetadata().getCoverImageUrl());
    		result.append(UNITY_SPLITTER);
    		result.append(s1.getMetadata().getPlayedTime());
    		result.append(UNITY_SPLITTER);
    		
    		SnapshotContents contents = s1.getSnapshotContents();
    		String data = contents == null ? "" : Base64.encode(contents.readFully());    		
    		result.append(data);
    		
    		result.append(UNITY_SPLITTER);
    		
    		result.append(s2.getMetadata().getTitle());
    		result.append(UNITY_SPLITTER);
    		result.append(s2.getMetadata().getLastModifiedTimestamp());
    		result.append(UNITY_SPLITTER);
    		result.append(s2.getMetadata().getDescription());
    		result.append(UNITY_SPLITTER);
    		result.append(s2.getMetadata().getCoverImageUrl());
    		result.append(UNITY_SPLITTER);
    		result.append(s2.getMetadata().getPlayedTime());
    		result.append(UNITY_SPLITTER);
    		
    		contents = s2.getSnapshotContents();
    		data = contents == null ? "" : Base64.encode(contents.readFully());
    		result.append(data);
    		 
    		 
            UnityPlayer.UnitySendMessage(GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnConflict", result.toString());
        } catch(IOException e) {
        	Log.d("AndroidNative", "GCM: snedConflict Exception:");
        	e.printStackTrace();
        }
	}
	

	
	private void loadFromSnapshot(final SnapshotMetadata snapshotMetadata) {
		if (snapshotMetadata != null && snapshotMetadata.getUniqueName() != null) {
			Log.i(TAG, "Opening snapshot by metadata: " + snapshotMetadata);
			Games.Snapshots.open(mHelper.getGoogleApiClient(), snapshotMetadata).setResultCallback(new OpenSnapshotListner("OnSavedGamePicked"));
		} else {
			Log.i(TAG, "Opening snapshot by name: " + currentSaveName);
			Games.Snapshots.open(mHelper.getGoogleApiClient(), currentSaveName, true).setResultCallback(new OpenSnapshotListner("OnSavedGamePicked"));
		}
	}
	
	
	
	

 
	
	
	// --------------------------------------
	// QUESTS AND EVENTS
	// --------------------------------------
	
	public void sumbitEvent(String eventId, int count) {
	    // increment the event counter
	    Games.Events.increment(mHelper.getGoogleApiClient(), eventId, count);
	}
	
	public void loadEvents() {
		 Games.Events.load(mHelper.getGoogleApiClient(), true).setResultCallback(new AN_EventsLoadListner());
	}
	

	
	public void showQuests() {
		Intent questsIntent = Games.Quests.getQuestsIntent(mHelper.getGoogleApiClient(), Quests.SELECT_ALL_QUESTS);
		 GooglePlaySupportActivity.startProxyForResult(questsIntent, 0);
	}
	
	
	public void showSelectedQuests(String questSelectors) {

		Intent questsIntent = Games.Quests.getQuestsIntent(mHelper.getGoogleApiClient(), getQuestSelectors(questSelectors));
		 GooglePlaySupportActivity.startProxyForResult(questsIntent, 0);
		
	}
	
	public void showQuest(String questId) {
		Intent questsIntent = Games.Quests.getQuestIntent(mHelper.getGoogleApiClient(), questId);
		 GooglePlaySupportActivity.startProxyForResult(questsIntent, 0);
	}
	
	public void acceptQuest(String questId) {
		Games.Quests.accept(mHelper.getGoogleApiClient(), questId).setResultCallback(new AN_AcceptQuestResultListner());
	}
	
	public void loadQuests(String questSelectors, int sortOrder) {
		Games.Quests.load(mHelper.getGoogleApiClient(), getQuestSelectors(questSelectors), sortOrder, true).setResultCallback(new AN_LoadQuestsResult());
	}
	
	public void claimQuest(Quest quest) {
		 Games.Quests.claim(mHelper.getGoogleApiClient(), quest.getQuestId(),quest.getCurrentMilestone().getMilestoneId()).setResultCallback(new AN_ClaimMilestoneResult());
	}
	
	public void updateQuest(Quest quest) {
		StringBuilder result = new StringBuilder();
		
		result.append(quest.getQuestId());
		result.append(UNITY_SPLITTER);
		result.append(quest.getName());
		result.append(UNITY_SPLITTER);
		result.append(quest.getDescription());
		result.append(UNITY_SPLITTER);
		
		result.append(quest.getBannerImageUrl());
		result.append(UNITY_SPLITTER);
		result.append(quest.getIconImageUrl());
		result.append(UNITY_SPLITTER);
		
		result.append(quest.getState());
		result.append(UNITY_SPLITTER);
		
		
		
		result.append(quest.getLastUpdatedTimestamp());
		result.append(UNITY_SPLITTER);
		result.append(quest.getAcceptedTimestamp());
		result.append(UNITY_SPLITTER);
		result.append(quest.getEndTimestamp());
		
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_QUESTS_LISTNER_NAME, "OnGPQuestUpdated", result.toString());
		
	}
	
	
	
	
	
	
	
	private static final String QUEST_QUERY_SEPARATOR = ",";
	public int[] getQuestSelectors(String questSelectors) {
		int[] values =  new int[0];
		if(questSelectors != null && questSelectors.length() > 0) {
			String[] requests = questSelectors.split(QUEST_QUERY_SEPARATOR);
			values = new int[requests.length];
			
			int index = 0;
			for(String query : requests) {
				values[index] = Integer.valueOf(query);
				index++;
			}
		}
		
		return values;
	}
	
	
	// --------------------------------------
	// CLOUD METHODS
	// --------------------------------------

	public void listStates() {
		//AppStateManager.list(mHelper.getGoogleApiClient()).setResultCallback(new StatesLoadedListener());
	}

	public void resolveState(int stateKey, String resolvedData, String resolvedVersion) {
		
		byte[] stateData = ConvertStringToCloudData(resolvedData);
		//AppStateManager.resolve(mHelper.getGoogleApiClient(), stateKey, resolvedVersion, stateData).setResultCallback(new StateUpdateListener());
	}

	public void updateState(int stateKey, String data) {
		CloudUpdateState(stateKey, ConvertStringToCloudData(data));
	}

	private void CloudUpdateState(int stateKey, byte[] stateData) {
		//AppStateManager.updateImmediate(mHelper.getGoogleApiClient(), stateKey, stateData).setResultCallback(new StateUpdateListener());
	}

	public void deleteState(int stateKey) {
		//AppStateManager.delete(mHelper.getGoogleApiClient(), stateKey).setResultCallback(new StateDeleteListener());
	}

	public void loadState(int stateKey) {
		//AppStateManager.load(mHelper.getGoogleApiClient(), stateKey).setResultCallback(new StateUpdateListener());
	}

	// --------------------------------------
	// GAME SERVICE METHODS
	// --------------------------------------

	
	public void clearDefaultAccount() {
		Log.d("AndroidNative", "clearDefaultAccountAndReconnect");
		mHelper.getGoogleApiClient().clearDefaultAccountAndReconnect();
	}
	
	public void revokeAccessAndDisconnect() {
		Plus.AccountApi.revokeAccessAndDisconnect(mHelper.getGoogleApiClient());
	}
	
	public void loadConnectedPlayers() {
		Games.Players.loadConnectedPlayers(mHelper.getGoogleApiClient(), true).setResultCallback(new PlayerResultListner());	
	}
	
	
	public void loadPlayerInfo(String playerId) {
		if(!isPlayerLoaded(playerId)) {
			addLoadedPlayerId(playerId);
			Games.Players.loadPlayer(mHelper.getGoogleApiClient(), playerId).setResultCallback(new PlayerResultListner());

		}
	}
	
	public void  loadGoogleAccountNames() {
		
		AccountManager mAccountManager = AccountManager.get(AnUtility.GetLauncherActivity());
		
		
		StringBuilder result = new StringBuilder();
	    Account[] accounts = mAccountManager.getAccountsByType( GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE);
	    for (int i = 0; i < accounts.length; i++) {
			result.append( accounts[i].name);
			result.append(UNITY_SPLITTER);
			
	    }
		result.append(UNITY_EOF);
	    
		
	    UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnAccountsLoaded", result.toString());
	}
	
	
	
	public void getToken(String accountName, String scope) {
		

		final String acc = accountName;
		final String sc = scope;
		
		AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {

			@Override
			protected Void doInBackground(Void... params) {
				String token = "";
				try {
					token =  GoogleAuthUtil.getToken(AnUtility.GetLauncherActivity(), acc, sc);
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage());
				}
				
				UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnTokenLoaded", token);
				return null;
			}
	          
		};
	   task.execute((Void)null);
	   
	}
	

	public void invalidateToken(String token) {
		GoogleAuthUtil.invalidateToken(AnUtility.GetLauncherActivity(), token);
	}
	

	public void resetLeaderBoard(String leaderboardId) {

		AsyncTask<String, String, String> task = new AsyncTask<String, String, String>() {

			
			@Override
			protected String doInBackground(String... params) {
				try {
					String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
					String token =  GoogleAuthUtil.getToken(AnUtility.GetLauncherActivity(), accountName, "oauth2:" + Games.SCOPE_GAMES.zznG());

					// Reset scores
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(
							"https://www.googleapis.com" + 
							"/games/v1management" +
							"/leaderboards/" +
							params[0] + 
							"/scores/reset" +
							"?access_token=" + token);
					
					
					client.execute(post);
					
					 
					 
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage() + e);
				}
				
				 Log.d("AndroidNative", "resetLeaderBoard done");
				
				return null;
			}
 
		};
		
	   task.execute(leaderboardId);
	}
	
	public void resetAllAchievements() {
		AsyncTask<String, String, String> task = new AsyncTask<String, String, String>() {

			@Override
			protected String doInBackground(String... params) {
				try {
					String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
					String token =  GoogleAuthUtil.getToken(AnUtility.GetLauncherActivity(), accountName, "oauth2:" + Games.SCOPE_GAMES.zznG());
					
					// Reset scores
					HttpClient client = new DefaultHttpClient();
					String r = "https://www.googleapis.com/games/v1management/achievements/reset?access_token=" + token;
					HttpPost post = new HttpPost(r );
					client.execute(post);
					 
					Log.d("AndroidNative", r);
					 
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage() + e);
				}
				
				GameClientManager.GetInstance().loadAchievements();
				Log.d("AndroidNative", "resetAllAchievements done");

				return null;
			}
 
		};
		
	   task.execute("");
	}
	
	public void resetAchievement(String achievementId) {
		AsyncTask<String, String, String> task = new AsyncTask<String, String, String>() {

			@Override
			protected String doInBackground(String... params) {
				try {
					String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
					String token =  GoogleAuthUtil.getToken(AnUtility.GetLauncherActivity(), accountName, "oauth2:" + Games.SCOPE_GAMES.zznG());
					
					// Reset scores
					HttpClient client = new DefaultHttpClient();
					String r = "https://www.googleapis.com/games/v1management/achievements/" + params[0] + "/reset?access_token=" + token;
					HttpPost post = new HttpPost(r );
					client.execute(post);
					 
					 Log.d("AndroidNative", r);
					 
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage() + e);
				}
				
				GameClientManager.GetInstance().loadAchievements();
				 Log.d("AndroidNative", "resetAchievement done");

				return null;
			}
 
		};
		
	   task.execute(achievementId);
	}
	
	

	// --------------------------------------
	// LEADER_BOARD
	// --------------------------------------

	public void showLeaderBoardsUI() {
		 GooglePlaySupportActivity.startProxyForResult(
				Games.Leaderboards.getAllLeaderboardsIntent(mHelper.getGoogleApiClient()), 
				LEADER_BOARDS_REQUEST);
	}

	public void showLeaderBoardUI(String leaderboardId) {
		 GooglePlaySupportActivity.startProxyForResult(
				Games.Leaderboards.getLeaderboardIntent(mHelper.getGoogleApiClient(), leaderboardId), 
				LEADER_BOARDS_REQUEST);
	}

	public void submitScore(String leaderboardId, long score) {
	
		Log.d("AndroidNative", "submitScore leaderboardId: " + leaderboardId + " score: " + score);
		Games.Leaderboards.submitScoreImmediate(mHelper.getGoogleApiClient(), leaderboardId, score).setResultCallback(new ScoreSubmitedListner(leaderboardId));
	}
	
	
	public void loadLeaderBoards() {
		Games.Leaderboards.loadLeaderboardMetadata(mHelper.getGoogleApiClient(), true).setResultCallback(new LeaderBoardsLoadedListener());
	}

	public void loadLeaderBoardsLocal(String leaderboardId, int requestId) {
		Log.d(TAG, "loadLeaderBoardsLocal: leaderboardId " + leaderboardId + " requestId " + requestId);
		
		Games.Leaderboards.loadCurrentPlayerLeaderboardScore(mHelper.getGoogleApiClient(),
				leaderboardId,
				LeaderboardVariant.TIME_SPAN_ALL_TIME,
				LeaderboardVariant.COLLECTION_PUBLIC)
				.setResultCallback(
						new PlayerScoreUpdateListner(LeaderboardVariant.TIME_SPAN_ALL_TIME,
								LeaderboardVariant.COLLECTION_PUBLIC, leaderboardId, requestId));
		
		Games.Leaderboards.loadCurrentPlayerLeaderboardScore(mHelper.getGoogleApiClient(),
				leaderboardId,
				LeaderboardVariant.TIME_SPAN_ALL_TIME,
				LeaderboardVariant.COLLECTION_SOCIAL)
				.setResultCallback(
						new PlayerScoreUpdateListner(LeaderboardVariant.TIME_SPAN_ALL_TIME,
								LeaderboardVariant.COLLECTION_SOCIAL, leaderboardId, requestId));
		
		Games.Leaderboards.loadCurrentPlayerLeaderboardScore(mHelper.getGoogleApiClient(),
				leaderboardId,
				LeaderboardVariant.TIME_SPAN_WEEKLY,
				LeaderboardVariant.COLLECTION_PUBLIC)
				.setResultCallback(
						new PlayerScoreUpdateListner(LeaderboardVariant.TIME_SPAN_WEEKLY,
								LeaderboardVariant.COLLECTION_PUBLIC, leaderboardId, requestId));
		
		Games.Leaderboards.loadCurrentPlayerLeaderboardScore(mHelper.getGoogleApiClient(),
				leaderboardId,
				LeaderboardVariant.TIME_SPAN_WEEKLY,
				LeaderboardVariant.COLLECTION_SOCIAL)
				.setResultCallback(
						new PlayerScoreUpdateListner(LeaderboardVariant.TIME_SPAN_WEEKLY,
								LeaderboardVariant.COLLECTION_SOCIAL, leaderboardId, requestId));
		
		Games.Leaderboards.loadCurrentPlayerLeaderboardScore(mHelper.getGoogleApiClient(),
				leaderboardId,
				LeaderboardVariant.TIME_SPAN_DAILY,
				LeaderboardVariant.COLLECTION_PUBLIC)
				.setResultCallback(
						new PlayerScoreUpdateListner(LeaderboardVariant.TIME_SPAN_DAILY,
								LeaderboardVariant.COLLECTION_PUBLIC, leaderboardId, requestId));
		
		Games.Leaderboards.loadCurrentPlayerLeaderboardScore(mHelper.getGoogleApiClient(),
				leaderboardId,
				LeaderboardVariant.TIME_SPAN_DAILY,
				LeaderboardVariant.COLLECTION_SOCIAL)
				.setResultCallback(
						new PlayerScoreUpdateListner(LeaderboardVariant.TIME_SPAN_DAILY,
								LeaderboardVariant.COLLECTION_SOCIAL, leaderboardId, requestId));
	}
	
	public void loadPlayerCenteredScores(String leaderboardId, int span, int leaderboardCollection, int maxResults) {
		  Log.d("AndroidNative", "loadPlayerCenteredScores");
		  Log.d("AndroidNative", Integer.toString(leaderboardCollection) );
		  Log.d("AndroidNative", Integer.toString(span) );
		  Games.Leaderboards.loadPlayerCenteredScores(mHelper.getGoogleApiClient(), leaderboardId, span, leaderboardCollection, maxResults, true).setResultCallback(new LeaderBoardScoreLoaded(span, leaderboardCollection, leaderboardId));
	}
	
	public void loadTopScores(String leaderboardId, int span, int leaderboardCollection, int maxResults) {
		Games.Leaderboards.loadTopScores(mHelper.getGoogleApiClient(), leaderboardId, span, leaderboardCollection, maxResults, true).setResultCallback(new LeaderBoardScoreLoaded(span, leaderboardCollection, leaderboardId));
	}
	
	

	// --------------------------------------
	// ACHIVMENTS
	// --------------------------------------

	public void showAchivmentsUI() {
		
		 GooglePlaySupportActivity.startProxyForResult(
				Games.Achievements.getAchievementsIntent(mHelper.getGoogleApiClient()), 
				ACHIEVEMENTS_REQUEST);
	}
	
	 

	public void reportAchievement(String id) {
		Games.Achievements.unlockImmediate(mHelper.getGoogleApiClient(), id).setResultCallback(new AchievementsUpdateListner());
	}

	public void incrementAchievement(String id, int numSteps) {
		Games.Achievements.incrementImmediate(mHelper.getGoogleApiClient(), id, numSteps).setResultCallback(new AchievementsUpdateListner());
	}
	
	public void setStepsImmediate(String id, int numSteps) {
		Games.Achievements.setStepsImmediate(mHelper.getGoogleApiClient(), id, numSteps).setResultCallback(new AchievementsUpdateListner());
	}

	public void revealAchievement(String id) {	
		Games.Achievements.revealImmediate(mHelper.getGoogleApiClient(), id).setResultCallback(new AchievementsUpdateListner());
	}

	public void loadAchievements() {
		
		loadAchievements(true);
	}
	
	public void loadAchievements(boolean forseLoad) {
		
		Games.Achievements.load(mHelper.getGoogleApiClient(), forseLoad).setResultCallback(new AchievementsLoadListner());
	}



	public void disconnect() {
		Log.d("AndroidNative", "Disconnected from play service");
		mHelper.disconnect();
	}
	
	public void connect() {
		mHelper.connect();
	}

	public void showAlert(String title, String message) {
		//mHelper.showAlert(title, message);
	}

	public void showAlert(String message) {
		//mHelper.showAlert(message);
	}

	 /**
     * Called when {@code mGoogleApiClient} is connected.
     */
    @Override
    public void onConnected(Bundle connectionHint) {
        Log.d("AndroidNative", "GoogleApiClient connected");
        GooglePlaySupportActivity.FinishActivity();
        
        
        StringBuilder result = new StringBuilder();
        Player player = Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient());
		
		result.append(player.getPlayerId());
		result.append(UNITY_SPLITTER);
		result.append(player.getDisplayName());
		result.append(UNITY_SPLITTER);
		result.append(player.getHiResImageUrl());
		result.append(UNITY_SPLITTER);
		result.append(player.getIconImageUrl());
		result.append(UNITY_SPLITTER);
		
		if(player.hasIconImage()) {
			result.append(1);
		} else {
			result.append(0);
		}
		
		result.append(UNITY_SPLITTER);
		
		if(player.hasHiResImage()) {
			result.append(1);
		} else {
			result.append(0);
		}
		
		result.append(UNITY_SPLITTER);
		try {
			String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
			result.append(accountName);
			Log.d("AndroidNative", "accountName " + accountName);
		} catch(Exception ex) {
			result.append("");
			Log.d("AndroidNative", "failed to get accountName");
			ex.printStackTrace();
		}
		
		
		
        
        UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnPlayerDataLoaded", result.toString());
        
       
        
        //Do we have any requests pending?
        mRequests = Games.Requests.getGameRequestsFromBundle(connectionHint);
        Log.d("AndroidNative", "onConnected: connection hint has " + mRequests.size() + " request(s)");
        
        if (!mRequests.isEmpty()) {
            // We have requests in onConnected's connectionHint.
           
        	result = new StringBuilder();
            for(GameRequest r : mRequests) {
            	result.append( r.getRequestId());
            	result.append(UNITY_SPLITTER);
            	String decoded = "";
				try {
					decoded = new String( r.getData(), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} 
            	result.append(decoded);
            	result.append(UNITY_SPLITTER);
            	result.append(r.getExpirationTimestamp() );
            	result.append(UNITY_SPLITTER);
            	result.append(r.getCreationTimestamp() );
            	result.append(UNITY_SPLITTER);
            	result.append(r.getSender().getPlayerId() );
            	result.append(UNITY_SPLITTER);
            	result.append(r.getType());
            	result.append(UNITY_SPLITTER);
            	
            }
            result.append(UNITY_EOF);
            
        	UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGameRequestsLoaded", result.toString());
        } else {
        	UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGameRequestsLoaded", "");
        }
        
        ReportConnectioResult(0);
		
		GameInvitationManager.GetInstance().onConnected(connectionHint);
		
		Games.Quests.registerQuestUpdateListener(mHelper.getGoogleApiClient(), new AN_QuestUpdateListener());
		
		Log.d("AndroidNative", "setViewForPopups");
		Games.setViewForPopups(API(),  AnUtility.GetLauncherActivity().getWindow().getDecorView());
		Log.d("AndroidNative", "AN_QuestUpdateListener registred");
		
		
		
		
	
    }
    
    

    
    
	// --------------------------------------
	// GIFTS
	// --------------------------------------
    
    public void sendGiftRequest(String type, String playload, String requestLifetimeDays, String icon, String description) {
	
		try {
			byte[] byteArray;
			byteArray = Base64.decode(icon);
			Bitmap media = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
			 
	    	
	    	Intent intent = Games.Requests.getSendIntent(mHelper.getGoogleApiClient(), Integer.valueOf(type), playload.getBytes(), Integer.valueOf(requestLifetimeDays), media, description);
	    	GooglePlaySupportActivity.startProxyForResult(intent, GIFT_REQUEST);
	   
	    	Log.d("AndroidNative", String.valueOf(GIFT_REQUEST));
	    	
		} catch (Base64DecoderException e) {
     		
     		UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGiftSendResult", "0");
			Log.d("AndroidNative", "sendGiftRequest: failed");
			e.printStackTrace();
		}
	}
    
    
    public void showRequestAccepDialog() {
    	 GooglePlaySupportActivity.startProxyForResult(Games.Requests.getInboxIntent(mHelper.getGoogleApiClient()), REQUESTS_INBOX_DIALOG);
    }
    
    public void acceptRequests(String ids) {
    	if(ids != null && ids.length() > 0) {
    		
    		ArrayList<GameRequest> list = new ArrayList<GameRequest>();
    		
			for(String id : ids.split(UNITY_SPLITTER)) {
				for(GameRequest r : mRequests) {
					if(r.getRequestId().equals(id)) {
						list.add(r);
					}
				}
			}
			
			if(!list.isEmpty()) {
				acceptRequests(list);
			}
    	}
    	
    }
    
    public void dismissRequest(String ids) {
    	if(ids != null && ids.length() > 0) {
    		
    		ArrayList<GameRequest> list = new ArrayList<GameRequest>();
    		
			for(String id : ids.split(UNITY_SPLITTER)) {
				for(GameRequest r : mRequests) {
					if(r.getRequestId().equals(id)) {
						list.add(r);
					}
				}
			}
			
			if(!list.isEmpty()) {
				dismissRequest(list);
			}
    	}
    	
    }
    
    
    public void acceptRequests(ArrayList<GameRequest> requests) {
    	// Attempt to accept these requests.
        ArrayList<String> requestIds = new ArrayList<String>();
        gameRequestMap  = new HashMap<String, GameRequest>();
        
        for (GameRequest request : requests) {
            String requestId = request.getRequestId();
            requestIds.add(requestId);
            gameRequestMap.put(requestId, request);
        }
        
        Games.Requests.acceptRequests(mHelper.getGoogleApiClient(), requestIds).setResultCallback(new AN_UpdateRequestsResultListner());
        
        
    }
    
    public void dismissRequest(ArrayList<GameRequest> requests) {
    	// Attempt to accept these requests.
        ArrayList<String> requestIds = new ArrayList<String>();
        gameRequestMap  = new HashMap<String, GameRequest>();
        
        for (GameRequest request : requests) {
            String requestId = request.getRequestId();
            requestIds.add(requestId);
            gameRequestMap.put(requestId, request);
        }
        
        Games.Requests.dismissRequests(mHelper.getGoogleApiClient(), requestIds).setResultCallback(new AN_UpdateRequestsResultListner());
        
    }
    
    

    
    public static boolean isPlayerLoaded(String id) {
    	if(loadedPlayers.contains(id)) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
    public static void addLoadedPlayerId(String id) {
    	if(!loadedPlayers.contains(id)) {
    		loadedPlayers.add(id);
    	}
    }
  

    /**
     * Called when {@code mGoogleApiClient} is disconnected.
     */
    @Override
    public void onConnectionSuspended(int cause) {
    	GooglePlaySupportActivity.FinishActivity();
    	Log.d("AndroidNative", "onConnectionSuspended");
        Log.d("AndroidNative", "GoogleApiClient connection suspended");
        
    }
    
    public void onSignInFailed() {
    	
    	Log.d("AndroidNative", "onSignInFailed");
    	GooglePlaySupportActivity.FinishActivity();
    	
    	
    	ReportConnectioResult(13);
    }

    
    private static void ReportConnectioResult(int resultCode) {
    	Log.d(TAG, "************** FINAL: Google Play Connection result: " + resultCode + " ************");
    	UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnConnectionResult", Integer.toString(resultCode));
    }

    private static ConnectionResult SavedConnectionResult;
	
    
    @Override
	public void onConnectionFailed(ConnectionResult arg0) {
		

		GooglePlaySupportActivity.FinishActivity();
		
		PS_Utility.PrintGooglePlayConnectionFailedResult(arg0);	 
	    

		if(arg0.hasResolution()) {
			 try {
					Handler handler = new Handler();
					SavedConnectionResult = arg0;
	
		
					// delay between sending result, since unity will report un-pause only in next frame
					handler.postDelayed(new Runnable() {
					            public void run() {
					            	mHelper.resolveConnection(SavedConnectionResult);
					            }
					        }, 1000);
				} catch (Exception ex) {
					ex.printStackTrace();
					Log.d("AndroidNative", "GooglePlaySupportActivity::onActivityResult Error: " + ex.getMessage());
				}
			 	
		 } else {
			 ReportConnectioResult(arg0.getErrorCode());
		 }
		
		
		if(arg0.getErrorCode() ==  GamesStatusCodes.STATUS_CLIENT_RECONNECT_REQUIRED) {
			mHelper.reconnect();
		}
		
		
	}
	
	public void onActivityResultDiconnectCheck(int request, int response, Intent data) {
		Log.d("AndroidNative", "GCM::onActivityResultDiconnectCheck");
		
		Log.d("AndroidNative", "GamesActivityResultCodes response " + response);
		
		if(response == GamesActivityResultCodes.RESULT_RECONNECT_REQUIRED) {
			 Log.d("AndroidNative", "GamesActivityResultCodes.RESULT_RECONNECT_REQUIRED");
			 Log.d("AndroidNative", "Disconnecting from play service...");
			 
			 UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnPlayServiceDisconnected", "");
			 ReconectOnStart = false;
			 disconnect();
		}
	}
	
	
	public void onActivityResult(int request, int response, Intent data) {

		
		Log.d("AndroidNative", "GCM::onActivityResult");
		

		switch (request) {
			case RC_LIST_SAVED_GAME:
				HandleSavedGamesUIResult(request, response, data);
				break;		
	        case ACHIEVEMENTS_REQUEST:
	        	Log.d("AndroidNative", "ACHIEVEMENTS_REQUEST returned");
	            break;
	        case GIFT_REQUEST:
	        	Log.d("AndroidNative", "Gift result code " + String.valueOf(response));
	
	        	StringBuilder result = new StringBuilder();
	     		result.append(response);
	     		
	     		UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGiftSendResult", result.toString());
	     		
	     		break;
	        case REQUESTS_INBOX_DIALOG:
	        	Log.d("AndroidNative", "GCM REQUESTS_INBOX_DIALOG");
	            if (response == Activity.RESULT_OK && data != null) {       
	            	Log.d("AndroidNative", "accepting requests");
	            	acceptRequests(Games.Requests.getGameRequestsFromInboxResponse(data));
	            } 
	            
	            UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnRequestsInboxDialogDismissed", "");
	            break;
		}
		
		RealTimeMultiplayerController.GetInstance().onActivityResult(request, response, data);
		TurnBasedMultiplayerController.GetInstance().onActivityResult(request, response, data);
		GameInvitationManager.GetInstance().onActivityResult(request, response, data);
	
		mHelper.onActivityResult(request, response, data);
		
		
	}
	
	private String currentSaveName = "";
	private void HandleSavedGamesUIResult(int request, int response, Intent data) {
		Log.d("AndroidNative", "HandleSavedGamesUIResult");
		if (data != null) {
	        if (data.hasExtra(Snapshots.EXTRA_SNAPSHOT_METADATA)) {
	            // Load a snapshot.
	            SnapshotMetadata snapshotMetadata = (SnapshotMetadata)  data.getParcelableExtra(Snapshots.EXTRA_SNAPSHOT_METADATA);
	            currentSaveName = snapshotMetadata.getUniqueName();
	            loadFromSnapshot(snapshotMetadata);
	            
	            Log.d("AndroidNative", "EXTRA_SNAPSHOT_METADATA");

	        } else if (data.hasExtra(Snapshots.EXTRA_SNAPSHOT_NEW)) {
	            // Create a new snapshot named with a unique string
	           // String unique = new BigInteger(281, new Random()).toString(13);
	           // currentSaveName = "snapshotTemp-" + unique;
	           // saveSnapshot();
	        	
	        	printLog("OnNewGameSaveRequest");
	        	
	        	UnityPlayer.UnitySendMessage(GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnNewGameSaveRequest", "");

	        }
	    } else {
	    	Log.d("AndroidNative", "nothing");
	    }
		
		
		
	}
	
	
	
	
	private void printLog(String msg) {
		Log.d("AndroidNative", "GameClientManager: " + msg);
	}

	public static String ConvertCloudDataToString(byte[] data) {
		String b = "";
		
		if(data == null) {
			return b;
		}

		int len = data.length;
		for (int i = 0; i < len; i++) {
			if (i != 0) {
				b += ",";
			}

			b += String.valueOf(data[i]);
		}

		return b;
	}

	public static byte[] ConvertStringToCloudData(String data) {
		
		String[] array = data.split("\\,");
		List<Byte> l = new ArrayList<Byte>();
		for (String b : array) {
			l.add(Byte.valueOf(b));
		}

		Byte[] B = l.toArray(new Byte[l.size()]);

		byte[] stateData = new byte[B.length];
		for (int i = 0; i < B.length; i++) {
			stateData[i] = B[i];
		}

		return stateData;
	}

	public static boolean isStarted() {
		return isStarted;
	}

	private boolean IsPlayServiceAlavliable() {
		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(AnUtility.GetLauncherActivity());
		
		Log.d(TAG, "IsPlayServiceAlavliable ConnectionResult:" + resultCode);
		
		if (resultCode == ConnectionResult.SUCCESS){
			return true;
		}
		 
		return false;
	}


	@Override
	public void onQuestCompleted(Quest arg0) {
		Log.d("AndroidNative", "onQuestCompleted: ");
		
	}
	
	
	// --------------------------------------
	// Utils
	// --------------------------------------
	
	
	public static String SerializeParticipantsInfo(ArrayList<Participant> participants) {
		StringBuilder info = new StringBuilder();
		
		for (Participant p : participants) {
			info.append(GameClientManager.SerializeParticipantInfo(p));
			info.append(GameClientManager.UNITY_SPLITTER);
		}
		
		info.append(GameClientManager.UNITY_EOF);
		
		return info.toString();
	}
	
	public static String SerializeParticipantInfo(Participant participant) {
		
		StringBuilder info = new StringBuilder();
		
		info.append(participant.getParticipantId());
		info.append(GameClientManager.UNITY_SPLITTER);
		
		if(participant.getPlayer() != null) {
			info.append(participant.getPlayer().getPlayerId());
			GetInstance().loadPlayerInfo(participant.getPlayer().getPlayerId());
		} else {
			info.append("-1");
		}
		info.append(GameClientManager.UNITY_SPLITTER);
		
		
		info.append(String.valueOf(participant.getStatus()));
		info.append(GameClientManager.UNITY_SPLITTER);
		
		info.append(participant.getHiResImageUrl());
		info.append(GameClientManager.UNITY_SPLITTER);
		
		info.append(participant.getIconImageUrl());
		info.append(GameClientManager.UNITY_SPLITTER);
		
		info.append(participant.getDisplayName());
		info.append(GameClientManager.UNITY_SPLITTER);
		
		
		if(participant.getResult() != null) {
			info.append(true);
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append(participant.getResult().getParticipantId());
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append(participant.getResult().getPlacing());
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append(participant.getResult().getResult());
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append(participant.getResult().getVersionCode());
		
			
		} else {
			info.append(false);
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append("0");
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append("0");
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append("0");
			info.append(GameClientManager.UNITY_SPLITTER);
			
			info.append("0");
		}
		
		
		
		return info.toString();

	}


}
