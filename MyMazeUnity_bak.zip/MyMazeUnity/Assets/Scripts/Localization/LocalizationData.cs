﻿
public class LocalizationData {
    public string key;
    public string represent;	
}
