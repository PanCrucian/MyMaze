﻿public class GateRecordData
{
    public GateStates gateState;
}
