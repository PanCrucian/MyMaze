﻿public class PositionRecordData {
    public GridObject.Position position;
}
