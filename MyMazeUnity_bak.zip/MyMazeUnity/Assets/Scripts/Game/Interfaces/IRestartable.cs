﻿using UnityEngine;
using System.Collections;

public interface IRestartable {

    void Restart();
}
