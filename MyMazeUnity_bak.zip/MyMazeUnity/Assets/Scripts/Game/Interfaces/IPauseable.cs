﻿using UnityEngine;
using System.Collections;

public interface IPauseable {

    void TogglePause(bool pause);
}
