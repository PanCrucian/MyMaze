﻿using UnityEngine;
using System.Collections;

public enum GameLevelStates {
    Pause,
    Game,
    GameOver,
    NextLevelLoading
}
