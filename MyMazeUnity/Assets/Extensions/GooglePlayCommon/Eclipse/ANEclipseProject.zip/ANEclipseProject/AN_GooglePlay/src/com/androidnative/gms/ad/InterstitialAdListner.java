package com.androidnative.gms.ad;

import android.util.Log;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.InterstitialAd;
import com.unity3d.player.UnityPlayer;

public class InterstitialAdListner extends AdListener  {
	
	private InterstitialAd _ad = null;
	public boolean IsShowAdOnLoad = true;
	

	public InterstitialAdListner(InterstitialAd ad) {
		_ad = ad;
	}
	
	
	 public void onAdLoaded() {
		 if(IsShowAdOnLoad) {
			 _ad.show();
		}
			
		Log.d("AndroidNative", "OnInterstitialAdLoaded: ");
		UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME, "OnInterstitialAdLoaded", "");
	 }
	 
	 public void onAdFailedToLoad(int errorCode) {
		 Log.d("AndroidNative", "onAdFailedToLoad: ");
		 UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME,"OnInterstitialAdFailedToLoad", "");
		 
	 }
	  
	 public void onAdOpened() {
		 Log.d("AndroidNative", "OnInterstitialAdOpened: ");
		 UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME,"OnInterstitialAdOpened", "");
	 }
	 
	 public void onAdClosed() {
		 Log.d("AndroidNative", "OnInterstitialAdClosed: ");
		 UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME,"OnInterstitialAdClosed", "");
	 }
	 
	 public void onAdLeftApplication() {
		 Log.d("AndroidNative", "OnInterstitialAdLeftApplication: ");
		 UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME,"OnInterstitialAdLeftApplication", "");
	 }
}
