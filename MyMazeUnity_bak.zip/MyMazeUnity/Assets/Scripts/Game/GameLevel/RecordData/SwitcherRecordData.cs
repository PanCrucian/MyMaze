﻿public class SwitcherRecordData
{
    public SwitcherStates switcherState;
    public float workingTime;
}
