package com.androidnative.gms.listeners.tbm;

import java.util.Iterator;

import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.network.TurnBasedMultiplayerController;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatch;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.LoadMatchesResult;
import com.unity3d.player.UnityPlayer;

public class AN_OnLoadMatchesResult implements ResultCallback<TurnBasedMultiplayer.LoadMatchesResult>{

	@Override
	public void onResult(LoadMatchesResult result) {		
		int statusCode = result.getStatus().getStatusCode();
		
		Log.d("AndroidNative", "AN_OnLoadMatchesResult  statusCode:" + statusCode);
		
		StringBuilder info = new StringBuilder();
		info.append(statusCode);		
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {			
			info.append(GameClientManager.UNITY_SPLITTER2);
			
			if(result.getMatches().getCompletedMatches() != null) {
				Iterator<TurnBasedMatch> CompletedMatches = result.getMatches().getCompletedMatches().iterator();				
				while (CompletedMatches.hasNext()) {
					TurnBasedMatch m = CompletedMatches.next();
					info.append(TurnBasedMultiplayerController.GetMatchString(m));
					info.append(GameClientManager.UNITY_SPLITTER2);
				}
				
				result.getMatches().getCompletedMatches().close();
			}
			
			if(result.getMatches().getMyTurnMatches() != null) {
				Iterator<TurnBasedMatch> MyTurnMatches = result.getMatches().getMyTurnMatches().iterator();				
				while (MyTurnMatches.hasNext()) {
					TurnBasedMatch m = MyTurnMatches.next();
					info.append(TurnBasedMultiplayerController.GetMatchString(m));
					info.append(GameClientManager.UNITY_SPLITTER2);
				}
				result.getMatches().getMyTurnMatches().close();
			}
			
			
			if(result.getMatches().getTheirTurnMatches() != null) {
				Iterator<TurnBasedMatch> TheirTurnMatches = result.getMatches().getTheirTurnMatches().iterator();				
				while (TheirTurnMatches.hasNext()) {
					TurnBasedMatch m = TheirTurnMatches.next();
					info.append(TurnBasedMultiplayerController.GetMatchString(m));
					info.append(GameClientManager.UNITY_SPLITTER2);
				}
				
				result.getMatches().getTheirTurnMatches().close();
			}
			
			info.append(GameClientManager.UNITY_EOF);
			
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_TBM_LISTENER, "OnLoadMatchesResult", info.toString());
	}

}
