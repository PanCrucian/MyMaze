﻿using UnityEngine;
using System.Collections;

public enum PlayerStates {
    Idle,
    Move,
    Die
}
