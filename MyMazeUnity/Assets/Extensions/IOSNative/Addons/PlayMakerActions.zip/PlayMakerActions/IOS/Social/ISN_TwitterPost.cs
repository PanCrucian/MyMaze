using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_TwitterPost : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			
			IOSSocialManager.instance.addEventListener(IOSSocialManager.TWITTER_POST_SUCCESS, OnPostSuccses);
			IOSSocialManager.instance.addEventListener(IOSSocialManager.TWITTER_POST_FAILED, OnPostFailed);
			
			IOSSocialManager.instance.TwitterPost(message.Value, texture.Value as Texture2D);
			
		}

		public override void Reset() {
			base.Reset();
			message   = "Message Text";
			
		}

		private void RemoveEvents() {
			IOSSocialManager.instance.removeEventListener(IOSSocialManager.FACEBOOK_POST_SUCCESS, OnPostSuccses);
			IOSSocialManager.instance.removeEventListener(IOSSocialManager.FACEBOOK_POST_FAILED, OnPostFailed);
		}

		
		
		private void OnPostFailed() {
			RemoveEvents();
			Fsm.Event(failEvent);
			Finish();
		}
		
		private void OnPostSuccses() {
			RemoveEvents();
			Fsm.Event(successEvent);
			Finish();
		}
		
	}
}



