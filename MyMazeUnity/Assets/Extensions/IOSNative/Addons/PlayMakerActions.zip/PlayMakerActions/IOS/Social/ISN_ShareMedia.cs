using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_ShareMedia : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public override void OnEnter() {

			IOSSocialManager.instance.ShareMedia(message.Value, texture.Value as Texture2D);
			
		}

		public override void Reset() {
			base.Reset();
			message   = "Message Text";
			
		}

	}
}



