﻿using UnityEngine;

public class WallBorder : MonoBehaviour {

}
