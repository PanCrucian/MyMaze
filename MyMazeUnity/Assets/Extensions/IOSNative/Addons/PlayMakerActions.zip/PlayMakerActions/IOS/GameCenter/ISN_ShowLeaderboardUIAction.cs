﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_ShowLeaderboardUIAction : FsmStateAction {

		public FsmString leaderboardId;
		public GCBoardTimeSpan timeSpan;


		public override void OnEnter() {
			GameCenterManager.ShowLeaderboard(leaderboardId.Value, timeSpan);
			Finish();
			
		}

	}
}

