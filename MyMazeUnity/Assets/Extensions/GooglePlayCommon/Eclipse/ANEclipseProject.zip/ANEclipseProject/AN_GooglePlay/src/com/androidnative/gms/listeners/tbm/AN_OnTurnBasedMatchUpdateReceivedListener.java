package com.androidnative.gms.listeners.tbm;

import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.network.TurnBasedMultiplayerController;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchUpdateReceivedListener;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatch;
import com.unity3d.player.UnityPlayer;

public class AN_OnTurnBasedMatchUpdateReceivedListener implements OnTurnBasedMatchUpdateReceivedListener{

	@Override
	public void onTurnBasedMatchReceived(TurnBasedMatch macth) {
		Log.d("AndroidNative", "AN_OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchReceived " + macth.getStatus() + " / " + macth.getTurnStatus());
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_TBM_LISTENER, "OnTurnBasedMatchReceived", TurnBasedMultiplayerController.GetMatchString(macth));
	}

	@Override
	public void onTurnBasedMatchRemoved(String matchId) {
		Log.d("AndroidNative", "AN_OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchRemoved " + matchId);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_TBM_LISTENER, "OnTurnBasedMatchRemoved", matchId);
	}
}
