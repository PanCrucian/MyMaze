﻿using UnityEngine;
using System.Collections;

public enum MusicStates {
    Normal
}
