﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - AppLicensing")]
	[Tooltip("Get Application License Status")]
	public class AN_GetLicenseStatus : FsmStateAction {

		public FsmEvent licenseAllowed;
		public FsmEvent licenseNotAllowed;

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif			
			
			if (IsInEdditorMode) {
				Fsm.Event (licenseAllowed);
				Finish ();
				return;
			}

			AN_LicenseManager.OnLicenseRequestResult += OnLicenseRequestResult;
			AN_LicenseManager.instance.StartLicenseRequest (AndroidNativeSettings.Instance.base64EncodedPublicKey);
			
		}

		private void OnLicenseRequestResult(AN_LicenseRequestResult result) {
			if (result == AN_LicenseRequestResult.RESULT_LICENSED) {
				Fsm.Event (licenseAllowed);
				Finish ();	
			} else {
				Fsm.Event (licenseNotAllowed);
				Finish ();
			}
		}
	}

}
