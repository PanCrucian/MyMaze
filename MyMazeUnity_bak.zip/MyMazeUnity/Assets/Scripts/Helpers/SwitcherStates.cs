﻿using UnityEngine;
using System.Collections;

public enum SwitcherStates {
    Off,
    TurnsOn,
    IsWorking,
    NowTurnOff,
    TurnsOff
}
