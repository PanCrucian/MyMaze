package com.androidnative.features.social.common;

import com.androidnative.features.social.gplus.GPlusShare;
import com.androidnative.features.social.twitter.ANTwitter;
import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

public class SocialProxyActivity extends Activity {
	private static final String BRIDGED_INTENT_KEY = "BRIDGED_INTENT";
	private static final String BRIDGED_REQUEST_CODE_KEY = "BRIDGED_REQUEST_CODE_KEY";
	private static final String TASK_ID = "TASK_ID";
	private static final String TWITTER_URL_KEY = "TWITTER_URL_KEY";	
	
	private static final int START_SOCIAL_SHARING_PROXY = 0;
	private static final int FINISH_SOCIAL_SHARING_PROXY = 1;
	private static final int START_GPLUS_SHARING_PROXY = 2;
	
	private static final int TWITTER_AUTH_TASK = 3;
	private static final int GPLUS_SHARE_TASK = 4;

	@Override
    protected void onStart() {			
		int taskID = getIntent().getIntExtra(TASK_ID, -1);
		Log.d("AndroidNative", "SocialProxyActivity::onStart " + taskID);
		
		switch(taskID) {
			case START_SOCIAL_SHARING_PROXY: 
				StartActivity();
				getIntent().putExtra(TASK_ID, FINISH_SOCIAL_SHARING_PROXY);
				break;
			case FINISH_SOCIAL_SHARING_PROXY: 
				SocialGate.RemoveImageFromStorage();
				finish();
				break;
			case START_GPLUS_SHARING_PROXY:
				StartActivity();
				break;
			case TWITTER_AUTH_TASK:
				Log.d("AndroidNative", "SocialProxyActivity::TWITTER_AUTH_TASK");				
				Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(getIntent().getStringExtra(TWITTER_URL_KEY)));				
				startActivityForResult(i, TWITTER_AUTH_TASK);
				break;
		}

        super.onStart();
    }
	
	
	public static void StartGPlusProxyActivity(Intent intent) {
		Log.d("AndroidNative", "SocialProxyActivity::StartGPlusProxyActivity");
		Intent i = new Intent(UnityPlayer.currentActivity, SocialProxyActivity.class);
		
		i.putExtra(TASK_ID, START_GPLUS_SHARING_PROXY);
		i.putExtra(BRIDGED_REQUEST_CODE_KEY, GPLUS_SHARE_TASK);
		i.putExtra(BRIDGED_INTENT_KEY, intent);
		

		UnityPlayer.currentActivity.startActivity(i);
	}
	
	public static void StartTwitterProxyActivity(String url) {
		Intent i = new Intent(UnityPlayer.currentActivity, SocialProxyActivity.class);		
		i.putExtra(TASK_ID, TWITTER_AUTH_TASK);
		i.putExtra(TWITTER_URL_KEY, url);
		
		UnityPlayer.currentActivity.startActivity(i);
	}
	
	private void StartActivity() {
		int requestCode = getIntent().getIntExtra(BRIDGED_REQUEST_CODE_KEY, 0);
		Intent bridgedIntent = (Intent) getIntent().getParcelableExtra(BRIDGED_INTENT_KEY);        
		startActivityForResult(bridgedIntent, requestCode);
	}
	
	 @Override
	 protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		Log.d("AndroidNative", "SocialProxyActivity::onActivityResult " + requestCode + " " + resultCode);
		
		switch (requestCode) {
			case SocialGate.REQ_START_SHARE:
				SocialGate.RemoveImageFromStorage();
				break;
			case TWITTER_AUTH_TASK:
				//Just nothing to do here. finish() method will do all the best � alexray
				break;
			case GPLUS_SHARE_TASK:
				UnityPlayer.UnitySendMessage(GPlusShare.PLUS_SHARE_LISTENER, GPlusShare.PLUS_SHARE_LISTENER_CALLBACK, Boolean.toString(resultCode == -1));
				break;
		}		
		
	 	super.onActivityResult(requestCode, resultCode, data);
	 	
	 	finish(); 
	 }
	 
	 
	@Override
	public void onNewIntent(Intent intent) {

		Log.d("AndroidNative", "SocialProxyActivity::onNewIntent");
		
		try {
			try {
				ANTwitter.GetInstance().SetIntent(intent);
			} catch (Throwable ex) {
				Log.d("AndroidNative", "SocialProxyActivity::onNewIntent has failed");
			}
		} catch(NoClassDefFoundError e) {
			Log.d("AndroidNative", "SocialProxyActivity::onNewIntent ANTwitter not found");
		}
		
		super.onNewIntent(intent);
	}

	
	
	public static void StartSocialSharingProxy(Intent intent, int requestCode) {
		Log.d("AndroidNative", "SocialProxyActivity::StartSocialSharingProxy requestCode: " + requestCode);
		Intent i = new Intent(UnityPlayer.currentActivity, SocialProxyActivity.class);
		
		i.putExtra(TASK_ID, START_SOCIAL_SHARING_PROXY);
		i.putExtra(BRIDGED_REQUEST_CODE_KEY, requestCode);
		i.putExtra(BRIDGED_INTENT_KEY, intent);
		

		UnityPlayer.currentActivity.startActivity(i);
	}	
}
