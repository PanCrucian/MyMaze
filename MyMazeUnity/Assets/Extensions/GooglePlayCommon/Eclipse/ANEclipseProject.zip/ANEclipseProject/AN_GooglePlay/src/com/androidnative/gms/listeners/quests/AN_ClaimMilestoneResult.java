package com.androidnative.gms.listeners.quests;
import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.quest.Quests;
import com.google.android.gms.games.quest.Quests.ClaimMilestoneResult;
import com.unity3d.player.UnityPlayer;


public class AN_ClaimMilestoneResult implements ResultCallback<Quests.ClaimMilestoneResult> {

	@Override
	public void onResult(ClaimMilestoneResult r) {
		
		Log.d(GameClientManager.TAG, "AN_ClaimMilestoneResult+");
		
		int statusCode = r.getStatus().getStatusCode();
		StringBuilder result = new StringBuilder();
		result.append(statusCode);
		result.append(GameClientManager.UNITY_SPLITTER);
		
		String reward = "";
		String questId = "0";
		
		
		if(r.getQuest() != null) {
			questId = r.getQuest().getQuestId();
		}
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			try {
				 reward = new String(r.getQuest().getCurrentMilestone().getCompletionRewardData(), "UTF-8");
		    } catch (Exception e) {
		    	Log.d(GameClientManager.TAG, "AN_ClaimMilestoneResult failed: " + e.getMessage());
			}
		}
		
		result.append(questId);
		result.append(GameClientManager.UNITY_SPLITTER);
		result.append(reward);

		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_QUESTS_LISTNER_NAME, "OnGPQuestCompleted", result.toString());
	
	}


	
}
