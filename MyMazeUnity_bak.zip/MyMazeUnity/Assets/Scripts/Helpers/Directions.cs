﻿using UnityEngine;
using System.Collections;

public enum Directions {
    Up,
    Right,
    Down,
    Left,
    Unknown
}
