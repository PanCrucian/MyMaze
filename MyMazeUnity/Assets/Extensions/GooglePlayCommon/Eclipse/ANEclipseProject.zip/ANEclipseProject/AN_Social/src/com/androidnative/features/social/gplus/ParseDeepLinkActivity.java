package com.androidnative.features.social.gplus;

import java.util.Collections;
import java.util.List;

import com.google.android.gms.plus.PlusShare;
import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.util.Log;

public class ParseDeepLinkActivity extends Activity {
	
	private final String ANDROID_NATIVE_PREFS = "ANDROID_NATIVE_PREFS";
	private final String LAUNCHED_DEEPLINK_ID = "LAUNCHED_DEEPLINK_ID";
	
	public static String _launcherDeepLinkId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        Log.d("AndroidNative", "ParseDeepLinkActivity OnCreate " + UnityPlayer.currentActivity);

        String deepLinkId = PlusShare.getDeepLinkId(this.getIntent());
        
        if (UnityPlayer.currentActivity != null) {
        	UnityPlayer.UnitySendMessage("AN_DeepLinkingManager", "DeepLinkReceived", deepLinkId);
        } else {
        	_launcherDeepLinkId = deepLinkId;
        	SharedPreferences.Editor editor = getSharedPreferences(ANDROID_NATIVE_PREFS, MODE_PRIVATE).edit();
        	editor.putString(LAUNCHED_DEEPLINK_ID, deepLinkId);
        	editor.commit();
        	
        	Intent launchIntent = getApplication().getPackageManager().getLaunchIntentForPackage(getApplication().getPackageName());
        	startActivity(launchIntent);
        }
        
        Log.d("AndroidNative", "deepLinkId " + deepLinkId);

        finish();
        
        Log.d("AndroidNative", "finish " + deepLinkId);
    }
}
