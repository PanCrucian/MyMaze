package com.androidnative.billing.core;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.os.Bundle;
import android.util.Log;

public class AN_BillingProxyActivity extends Activity {

	private BroadcastReceiver broadcastReceiver;
	public static final String ACTION_FINISH = "com.androidnative.billing.core.ACTION_FINISH";
	
	private static int _currentRequestCode = -1;
	
	private boolean resultWasSet = false;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
    	Log.d("AndroidNative", "AN_BillingProxyActivity::onCreate");
        super.onCreate(savedInstanceState);

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.d(BillingManager.TAG, "Finish AN_BillingProxyActivity broadcast was received");
                if (!AN_BillingProxyActivity.this.isFinishing()) {
                    finish();
                }
            }
        };
        registerReceiver(broadcastReceiver, new IntentFilter(ACTION_FINISH));

        if (BillingManager.sendRequest) {
        	BillingManager.sendRequest = false;

            Intent i = getIntent();
            String sku = i.getStringExtra("sku");
            String developerPayload = i.getStringExtra("developerPayload");
            boolean inapp = i.getBooleanExtra("inapp", true);

            
            if (inapp) {
            	BillingManager.GetInstance().launchPurchaseFlow(this, sku, developerPayload);
            } else {
            	BillingManager.GetInstance().launchSubscribeFlow(this, sku, developerPayload);
            }
           
        }
    }
    
    @Override
	public void startIntentSenderForResult(IntentSender intent, int requestCode, Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags) throws SendIntentException {
    	_currentRequestCode = requestCode;
    	super.startIntentSenderForResult(intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags);
    }
    
    @Override
    protected void onStop() {
		 Log.d("AndroidNative", "AN_BillingProxyActivity::onStop");
		 if(!resultWasSet) {
			 BillingManager.GetInstance().handleActivityResult(_currentRequestCode, Activity.RESULT_CANCELED, null);
		 }
		 super.onStop();
	}

    @Override
    protected void onDestroy() {
    	 Log.d("AndroidNative", "AN_BillingProxyActivity::onDestroy");
    	 
    	 
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	
    	resultWasSet = true;
        Log.d(BillingManager.TAG, "AN_BillingProxyActivity::onActivityResult(" + requestCode + ", " + resultCode + ", " + data);
        
        BillingManager.GetInstance().handleActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

        /*
        // Pass on the activity result to the helper for handling
        if (!UnityPlugin.instance().getHelper().handleActivityResult(requestCode, resultCode, data)) {
            // not handled, so handle it ourselves (here's where you'd
            // perform any handling of activity results not related to in-app
            // billing...
            super.onActivityResult(requestCode, resultCode, data);
        } else {
            Log.d(BillingManager.TAG, "onActivityResult handled by IABUtil.");
        }
        */
    }
}
