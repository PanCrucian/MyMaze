﻿public class BoxStrongRecordData
{
    public bool yellowColliderEnabled;
    public bool whiteColliderEnabled;
}
