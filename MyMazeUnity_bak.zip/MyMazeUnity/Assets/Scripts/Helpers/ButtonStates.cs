﻿using UnityEngine;
using System.Collections;

public enum ButtonStates {
    Off,
    On
}
