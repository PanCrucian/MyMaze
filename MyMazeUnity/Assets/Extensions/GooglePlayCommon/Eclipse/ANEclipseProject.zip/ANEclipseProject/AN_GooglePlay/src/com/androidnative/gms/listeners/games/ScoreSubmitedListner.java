package com.androidnative.gms.listeners.games;

import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.leaderboard.LeaderboardVariant;
import com.google.android.gms.games.leaderboard.Leaderboards;
import com.google.android.gms.games.leaderboard.Leaderboards.SubmitScoreResult;
import com.unity3d.player.UnityPlayer;



public class ScoreSubmitedListner implements ResultCallback<Leaderboards.SubmitScoreResult> {
	
	
	private String _leaderboardId;

	
	public ScoreSubmitedListner(String leaderboardId) {
		_leaderboardId = leaderboardId;
	}
	
	

	@Override
	public void onResult(SubmitScoreResult arg0) {
		
		int statusCode = arg0.getStatus().getStatusCode();
		

			
		Log.d("AndroidNative", "Status: " + statusCode + " leaderboardId: " + _leaderboardId);

		if(statusCode == GamesStatusCodes.STATUS_OK) {

			Log.d("AndroidNative", "New Score TIME_SPAN_ALL_TIME: "  + arg0.getScoreData().getScoreResult(LeaderboardVariant.TIME_SPAN_ALL_TIME).rawScore);
			Log.d("AndroidNative", "New Score TIME_SPAN_WEEKLY: "    + arg0.getScoreData().getScoreResult(LeaderboardVariant.TIME_SPAN_WEEKLY).rawScore);
			Log.d("AndroidNative", "New Score TIME_SPAN_DAILY: "     + arg0.getScoreData().getScoreResult(LeaderboardVariant.TIME_SPAN_DAILY).rawScore);
		} 


		StringBuilder playerInfo = new StringBuilder();
		playerInfo.append(statusCode);
		playerInfo.append(GameClientManager.UNITY_SPLITTER);
		playerInfo.append(_leaderboardId);
		
		
		
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnScoreSubmitted", playerInfo.toString());
		
	}
	
}
