package com.androidnative.gms.utils;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

public class AnUtility {

	private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
	
	
	public static Activity GetLauncherActivity() {
		return UnityPlayer.currentActivity;
	}
	
	
	public static Context GetApplicationContex() {
		return GetLauncherActivity().getApplicationContext();
	}
	
	

	/**
	 * Check the device to make sure it has the Google Play Services APK. If it
	 * doesn't, display a dialog that allows users to download the APK from the
	 * Google Play Store or enable it in the device's system settings.
	 */
	public static boolean checkPlayServices() {
		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(GetLauncherActivity());
		if (resultCode != ConnectionResult.SUCCESS) {
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
				GooglePlayServicesUtil.getErrorDialog(resultCode, GetLauncherActivity(), PLAY_SERVICES_RESOLUTION_REQUEST).show();
			} else {
				Log.i("AndroidNative", "This device is not supported.");
				GetLauncherActivity().finish();
			}
			return false;
		}
		return true;
	}
}
