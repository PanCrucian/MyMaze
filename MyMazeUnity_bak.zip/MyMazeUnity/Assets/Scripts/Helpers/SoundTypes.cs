﻿public enum SoundTypes {
	sounds,
    theme
}
