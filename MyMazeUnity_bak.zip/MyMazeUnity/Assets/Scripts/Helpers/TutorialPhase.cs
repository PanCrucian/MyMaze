﻿using UnityEngine;
using System.Collections;

public enum TutorialPhase {
    HowToMove,
    Teleport,
    TimeMachine,
    NotTeach
}
