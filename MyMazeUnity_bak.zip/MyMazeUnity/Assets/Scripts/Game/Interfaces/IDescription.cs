﻿public interface IDescription {

    string GetName();

}
