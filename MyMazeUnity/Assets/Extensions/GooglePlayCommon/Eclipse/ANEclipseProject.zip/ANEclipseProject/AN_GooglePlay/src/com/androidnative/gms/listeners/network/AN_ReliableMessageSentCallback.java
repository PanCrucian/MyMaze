package com.androidnative.gms.listeners.network;

import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMultiplayer.ReliableMessageSentCallback;
import com.unity3d.player.UnityPlayer;

public class AN_ReliableMessageSentCallback implements ReliableMessageSentCallback {
	
	private String _RoomId;
	private int _DataTokenId;
	
	public AN_ReliableMessageSentCallback(String roomId, int dataTokenId) {
		_RoomId = roomId;
		_DataTokenId = dataTokenId;
	}

	@Override
	public void onRealTimeMessageSent(int statusCode, int tokenId, String recipientParticipantId) {
		
		StringBuilder builder = new StringBuilder();
		builder.append(Integer.toString(statusCode));
		builder.append(GameClientManager.UNITY_SPLITTER);
		builder.append(_RoomId);
		builder.append(GameClientManager.UNITY_SPLITTER);
		builder.append(Integer.toString(tokenId));
		builder.append(GameClientManager.UNITY_SPLITTER);
		builder.append(Integer.toString(_DataTokenId));
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnReliableMessageDelivered", builder.toString());
	}

}
