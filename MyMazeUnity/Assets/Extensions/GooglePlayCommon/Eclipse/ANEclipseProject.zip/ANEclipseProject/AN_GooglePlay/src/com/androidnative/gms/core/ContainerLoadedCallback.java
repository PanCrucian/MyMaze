package com.androidnative.gms.core;

import com.google.android.gms.tagmanager.Container;
import com.google.android.gms.tagmanager.ContainerHolder;
import com.google.android.gms.tagmanager.ContainerHolder.ContainerAvailableListener;

public class ContainerLoadedCallback implements ContainerAvailableListener{

	public static void registerCallbacksForContainer(Container container) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void onContainerAvailable(ContainerHolder arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

}
