package com.androidnative.features.social.utils;

import android.app.Activity;

import com.unity3d.player.UnityPlayer;

public class SocialConf {
	/**
	 * Tag used on log messages.
	 */
	public static final String TAG = "AndroidNative";

	
	/**
	 * Splitters.
	 */
	public static final String UNITY_SPLITTER = "|";
	public static final String UNITY_EOF = "endofline";
	
	
	public static Activity GetLauncherActivity() {
		return UnityPlayer.currentActivity;
	}
	
}
